import React, { useState, useEffect } from 'react';
import { 
  AppSettings, 
  EvaluationResult, 
  Language, 
  UserProfile 
} from './types';
import { 
  DEFAULT_SETTINGS, 
  getAppSettings, 
  getDashboardStats, 
  getLastResult, 
  getPracticeHistory, 
  getUserProfile, 
  saveAppSettings, 
  saveHistoryItem, 
  saveUserProfile 
} from './utils/storage';
import { soundManager } from './utils/sound';
import { LoginScreen } from './components/LoginScreen';
import { Header } from './components/Header';
import { Dashboard } from './components/Dashboard';
import { PageTyping } from './components/PageTyping';
import { TextPractice } from './components/TextPractice';
import { TypingTest } from './components/TypingTest';
import { ResultScreen } from './components/ResultScreen';
import { PracticeHistory } from './components/PracticeHistory';
import { SettingsModal } from './components/SettingsModal';
import { HindiGuideModal } from './components/HindiGuideModal';

type ActiveScreen = 'dashboard' | 'page_typing' | 'text_practice' | 'typing_test' | 'history' | 'result';

export default function App() {
  // User profile
  const [user, setUser] = useState<UserProfile | null>(() => getUserProfile());

  // Settings
  const [settings, setSettings] = useState<AppSettings>(() => getAppSettings());

  // Active Language
  const [currentLanguage, setCurrentLanguage] = useState<Language>(() => {
    const savedUser = getUserProfile();
    return savedUser?.preferredLanguage || getAppSettings().defaultLanguage || 'english';
  });

  // Navigation screen
  const [activeScreen, setActiveScreen] = useState<ActiveScreen>(() => {
    const saved = getAppSettings();
    return saved.defaultMode || 'dashboard';
  });

  // History & Results
  const [history, setHistory] = useState<EvaluationResult[]>(() => getPracticeHistory());
  const [currentResult, setCurrentResult] = useState<EvaluationResult | null>(() => getLastResult());

  // Modals
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isHindiGuideOpen, setIsHindiGuideOpen] = useState(false);

  // Initialize theme & sound settings
  useEffect(() => {
    if (settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    soundManager.setEnabled(settings.soundEnabled);
  }, [settings]);

  // Handle Login
  const handleLogin = (newUser: UserProfile) => {
    saveUserProfile(newUser);
    setUser(newUser);
    setCurrentLanguage(newUser.preferredLanguage);

    const updatedSettings: AppSettings = {
      ...settings,
      studentName: newUser.name,
      defaultLanguage: newUser.preferredLanguage,
    };
    saveAppSettings(updatedSettings);
    setSettings(updatedSettings);

    setActiveScreen('dashboard');
  };

  // Language Change handler
  const handleLanguageChange = (lang: Language) => {
    setCurrentLanguage(lang);
    if (user) {
      const updatedUser = { ...user, preferredLanguage: lang };
      saveUserProfile(updatedUser);
      setUser(updatedUser);
    }
  };

  // Toggle Theme
  const handleToggleTheme = () => {
    const nextTheme: 'light' | 'dark' = settings.theme === 'dark' ? 'light' : 'dark';
    const updated: AppSettings = { ...settings, theme: nextTheme };
    saveAppSettings(updated);
    setSettings(updated);
  };

  // Handle Result Submission
  const handleSubmitResult = (result: EvaluationResult) => {
    saveHistoryItem(result);
    setHistory(getPracticeHistory());
    setCurrentResult(result);
    setActiveScreen('result');
  };

  // Dashboard Stats
  const dashboardStats = getDashboardStats(currentLanguage);

  // If student is not logged in, show Login / Setup screen first
  if (!user) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors">
      {/* Top Navigation Header */}
      <Header
        activeScreen={activeScreen}
        onNavigate={setActiveScreen}
        user={user}
        currentLanguage={currentLanguage}
        onLanguageChange={handleLanguageChange}
        hasLastResult={!!currentResult}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onOpenHindiGuide={() => setIsHindiGuideOpen(true)}
        settings={settings}
        onToggleTheme={handleToggleTheme}
      />

      {/* Main Content Body */}
      <main className="flex-1 pb-12">
        {activeScreen === 'dashboard' && (
          <Dashboard
            user={user}
            stats={dashboardStats}
            currentLanguage={currentLanguage}
            onLanguageChange={handleLanguageChange}
            onNavigate={setActiveScreen}
            onOpenSettings={() => setIsSettingsOpen(true)}
            hasLastResult={!!currentResult}
          />
        )}

        {activeScreen === 'page_typing' && (
          <PageTyping
            currentLanguage={currentLanguage}
            onLanguageChange={handleLanguageChange}
            studentName={user.name}
            settings={settings}
            onBack={() => setActiveScreen('dashboard')}
            onSubmitResult={handleSubmitResult}
            onOpenHindiGuide={() => setIsHindiGuideOpen(true)}
          />
        )}

        {activeScreen === 'text_practice' && (
          <TextPractice
            currentLanguage={currentLanguage}
            onLanguageChange={handleLanguageChange}
            studentName={user.name}
            settings={settings}
            onBack={() => setActiveScreen('dashboard')}
            onSubmitResult={handleSubmitResult}
            onOpenHindiGuide={() => setIsHindiGuideOpen(true)}
          />
        )}

        {activeScreen === 'typing_test' && (
          <TypingTest
            currentLanguage={currentLanguage}
            onLanguageChange={handleLanguageChange}
            studentName={user.name}
            settings={settings}
            onBack={() => setActiveScreen('dashboard')}
            onSubmitResult={handleSubmitResult}
            onOpenHindiGuide={() => setIsHindiGuideOpen(true)}
          />
        )}

        {activeScreen === 'result' && currentResult && (
          <ResultScreen
            result={currentResult}
            onTryAgain={() => setActiveScreen(currentResult.mode === 'typing_test' ? 'typing_test' : 'page_typing')}
            onChooseNewPassage={() => setActiveScreen('page_typing')}
            onViewHistory={() => setActiveScreen('history')}
            onBackToDashboard={() => setActiveScreen('dashboard')}
          />
        )}

        {activeScreen === 'history' && (
          <PracticeHistory
            history={history}
            onSelectResult={(item) => {
              setCurrentResult(item);
              setActiveScreen('result');
            }}
            onRefreshHistory={() => setHistory(getPracticeHistory())}
            onBack={() => setActiveScreen('dashboard')}
          />
        )}
      </main>

      {/* Settings Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        settings={settings}
        user={user}
        onUpdateSettings={setSettings}
        onUpdateUser={setUser}
        onResetAll={() => {
          setUser(null);
          setHistory([]);
          setCurrentResult(null);
          setSettings(DEFAULT_SETTINGS);
        }}
      />

      {/* Hindi Typing Guide & Character Pad Modal */}
      <HindiGuideModal
        isOpen={isHindiGuideOpen}
        onClose={() => setIsHindiGuideOpen(false)}
      />
    </div>
  );
}
