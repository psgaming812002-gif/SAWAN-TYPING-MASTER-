import React, { useState } from 'react';
import { 
  Keyboard, 
  BookOpen, 
  PenTool, 
  Clock, 
  History, 
  Award, 
  Settings, 
  Languages, 
  Menu, 
  X, 
  HelpCircle,
  Sun,
  Moon
} from 'lucide-react';
import { AppSettings, Language, PracticeMode, UserProfile } from '../types';

interface Props {
  activeScreen: 'dashboard' | 'page_typing' | 'text_practice' | 'typing_test' | 'history' | 'result';
  onNavigate: (screen: 'dashboard' | 'page_typing' | 'text_practice' | 'typing_test' | 'history' | 'result') => void;
  user: UserProfile | null;
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
  hasLastResult: boolean;
  onOpenSettings: () => void;
  onOpenHindiGuide: () => void;
  settings: AppSettings;
  onToggleTheme: () => void;
}

export const Header: React.FC<Props> = ({
  activeScreen,
  onNavigate,
  user,
  currentLanguage,
  onLanguageChange,
  hasLastResult,
  onOpenSettings,
  onOpenHindiGuide,
  settings,
  onToggleTheme,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  interface NavItem {
    id: 'dashboard' | 'page_typing' | 'text_practice' | 'typing_test' | 'history';
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    highlight?: boolean;
  }

  const navItems: NavItem[] = [
    { id: 'dashboard', label: 'Dashboard', icon: Keyboard },
    { 
      id: 'page_typing', 
      label: currentLanguage === 'hindi' ? 'पेज देखकर टाइपिंग' : 'Page Dekhkar Typing', 
      icon: BookOpen, 
      highlight: true 
    },
    { id: 'text_practice', label: 'Text Practice', icon: PenTool },
    { id: 'typing_test', label: 'Typing Test (Exam)', icon: Clock },
    { id: 'history', label: 'Practice History', icon: History },
  ];

  const handleNavClick = (screen: Props['activeScreen']) => {
    onNavigate(screen);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & App Name */}
          <div 
            onClick={() => handleNavClick('dashboard')}
            className="flex items-center gap-3 cursor-pointer select-none group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 via-blue-600 to-cyan-500 flex items-center justify-center text-white shadow-md shadow-indigo-500/20 group-hover:scale-105 transition-transform">
              <Keyboard className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-base tracking-tight text-slate-900 dark:text-white leading-tight">
                  SAWAN TYPING
                </span>
                <span className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-bold uppercase rounded bg-indigo-50 text-indigo-700 dark:bg-indigo-950/70 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800">
                  {currentLanguage.toUpperCase()}
                </span>
              </div>
              <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                {currentLanguage === 'hindi' ? 'हिंदी एवं अंग्रेजी टंकण अभ्यास' : 'Hindi & English Typing Practice'}
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeScreen === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? item.highlight
                        ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-500/30'
                        : 'bg-slate-100 dark:bg-slate-800 text-indigo-600 dark:text-indigo-400'
                      : item.highlight
                      ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/50 hover:bg-indigo-100 font-bold border border-indigo-200 dark:border-indigo-800'
                      : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{item.label}</span>
                </button>
              );
            })}

            {hasLastResult && (
              <button
                onClick={() => handleNavClick('result')}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                  activeScreen === 'result'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 dark:hover:bg-emerald-900/40'
                }`}
              >
                <Award className="w-3.5 h-3.5" />
                <span>My Results</span>
              </button>
            )}
          </nav>

          {/* Right Action Icons & Profile */}
          <div className="flex items-center gap-2">
            {/* Quick Language Toggle */}
            <button
              onClick={() => onLanguageChange(currentLanguage === 'hindi' ? 'english' : 'hindi')}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              title="Switch Language"
            >
              <Languages className="w-3.5 h-3.5 text-indigo-500" />
              <span>{currentLanguage === 'hindi' ? 'हिन्दी' : 'English'}</span>
            </button>

            {/* Hindi Keyboard Guide Button */}
            <button
              onClick={onOpenHindiGuide}
              className="p-2 text-slate-600 dark:text-slate-300 hover:text-orange-600 hover:bg-orange-50 dark:hover:bg-orange-950/40 rounded-lg transition-colors"
              title="Hindi Keyboard Guide"
            >
              <HelpCircle className="w-4 h-4" />
            </button>

            {/* Theme Toggle */}
            <button
              onClick={onToggleTheme}
              className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
              title="Toggle Dark/Light Mode"
            >
              {settings.theme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 text-slate-600" />
              )}
            </button>

            {/* Settings Button */}
            <button
              onClick={onOpenSettings}
              className="p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
              title="Open Settings"
            >
              <Settings className="w-4 h-4" />
            </button>

            {/* Student Name Pill */}
            {user && (
              <div 
                onClick={onOpenSettings}
                className="hidden sm:flex items-center gap-2 pl-2 border-l border-slate-200 dark:border-slate-800 cursor-pointer"
                title="Click to change student name"
              >
                <div className="w-7 h-7 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-xs shadow-xs">
                  {user.name.charAt(0).toUpperCase()}
                </div>
                <span className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate max-w-[100px]">
                  {user.name}
                </span>
              </div>
            )}

            {/* Mobile Menu Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden px-4 pt-2 pb-4 space-y-1 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 shadow-lg animate-in slide-in-from-top-2 duration-150">
          {user && (
            <div className="flex items-center gap-2 p-2.5 mb-2 bg-indigo-50 dark:bg-indigo-950/40 rounded-xl">
              <div className="w-8 h-8 rounded-full bg-indigo-600 text-white flex items-center justify-center font-bold text-xs">
                {user.name.charAt(0).toUpperCase()}
              </div>
              <div>
                <span className="text-xs font-bold text-slate-900 dark:text-white block">
                  {user.name}
                </span>
                <span className="text-[10px] text-indigo-600 dark:text-indigo-400">
                  {currentLanguage === 'hindi' ? 'हिंदी मोड सक्रिय' : 'English Mode Active'}
                </span>
              </div>
            </div>
          )}

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeScreen === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold text-left transition-colors ${
                  isActive
                    ? item.highlight
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-100 dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 font-bold'
                    : item.highlight
                    ? 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/50 font-bold'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
              </button>
            );
          })}

          {hasLastResult && (
            <button
              onClick={() => handleNavClick('result')}
              className="w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-xs font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40"
            >
              <Award className="w-4 h-4" />
              <span>My Results</span>
            </button>
          )}

          <div className="pt-2 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
            <button
              onClick={() => {
                onOpenHindiGuide();
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-1.5 text-xs text-orange-600 dark:text-orange-400 font-medium py-1 px-2"
            >
              <HelpCircle className="w-4 h-4" /> हिंदी कीबोर्ड गाइड
            </button>
            <button
              onClick={() => {
                onOpenSettings();
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-400 font-medium py-1 px-2"
            >
              <Settings className="w-4 h-4" /> Settings
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
