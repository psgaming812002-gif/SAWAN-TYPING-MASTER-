import React, { useState } from 'react';
import { X, Smartphone, Monitor, BookOpen, Sparkles, Copy, Check } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onInsertChar?: (char: string) => void;
}

export const HindiGuideModal: React.FC<Props> = ({ isOpen, onClose, onInsertChar }) => {
  const [activeTab, setActiveTab] = useState<'mobile' | 'desktop' | 'vowels' | 'consonants' | 'matras'>('mobile');
  const [copiedChar, setCopiedChar] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (char: string) => {
    if (onInsertChar) {
      onInsertChar(char);
    }
    navigator.clipboard?.writeText(char);
    setCopiedChar(char);
    setTimeout(() => setCopiedChar(null), 1500);
  };

  const vowels = [
    { char: 'अ', label: 'a' }, { char: 'आ', label: 'aa' }, { char: 'इ', label: 'i' },
    { char: 'ई', label: 'ee' }, { char: 'उ', label: 'u' }, { char: 'ऊ', label: 'oo' },
    { char: 'ऋ', label: 'ri' }, { char: 'ए', label: 'e' }, { char: 'ऐ', label: 'ai' },
    { char: 'ओ', label: 'o' }, { char: 'औ', label: 'au' }, { char: 'अं', label: 'am' },
    { char: 'अः', label: 'ah' }
  ];

  const matras = [
    { char: 'ा', name: 'आ की मात्रा', example: 'का' },
    { char: 'ि', name: 'इ की मात्रा (ह्रस्व)', example: 'कि' },
    { char: 'ी', name: 'ई की मात्रा (दीर्घ)', example: 'की' },
    { char: 'ु', name: 'उ की मात्रा', example: 'कु' },
    { char: 'ू', name: 'ऊ की मात्रा', example: 'कू' },
    { char: 'ृ', name: 'ऋ की मात्रा', example: 'कृ' },
    { char: 'े', name: 'ए की मात्रा', example: 'के' },
    { char: 'ै', name: 'ऐ की मात्रा', example: 'कै' },
    { char: 'ो', name: 'ओ की मात्रा', example: 'को' },
    { char: 'ौ', name: 'औ की मात्रा', example: 'कौ' },
    { char: 'ं', name: 'अनुस्वार (बिंदु)', example: 'कं' },
    { char: 'ँ', name: 'अनुनासिक (चन्द्रबिन्दु)', example: 'कँ' },
    { char: '्', name: 'हलन्त (आधा अक्षर)', example: 'क्' },
    { char: 'ः', name: 'विसर्ग', example: 'कः' },
    { char: '़', name: 'नुक्ता', example: 'क़' },
    { char: '।', name: 'पूर्ण विराम (खड़ी पाई)', example: 'राम।' }
  ];

  const consonants = [
    'क', 'ख', 'ग', 'घ', 'ङ',
    'च', 'छ', 'ज', 'झ', 'ञ',
    'ट', 'ठ', 'ड', 'ढ', 'ण',
    'त', 'थ', 'द', 'ध', 'न',
    'प', 'फ', 'ब', 'भ', 'म',
    'य', 'र', 'ल', 'व', 'श',
    'ष', 'स', 'ह', 'क्ष', 'त्र', 'ज्ञ', 'श्र'
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-orange-500/10 text-orange-600 dark:text-orange-400 flex items-center justify-center font-bold text-lg">
              अ
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                Hindi Typing Guide & Keyboard Helper
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                हिंदी टाइपिंग कैसे करें और मुख्य वर्ण निर्देश
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 px-6 bg-slate-50/50 dark:bg-slate-800/30 overflow-x-auto">
          <button
            onClick={() => setActiveTab('mobile')}
            className={`flex items-center gap-2 py-3 px-3 text-xs md:text-sm font-semibold border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'mobile'
                ? 'border-orange-500 text-orange-600 dark:text-orange-400'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Smartphone className="w-4 h-4" /> Android (Gboard)
          </button>
          <button
            onClick={() => setActiveTab('desktop')}
            className={`flex items-center gap-2 py-3 px-3 text-xs md:text-sm font-semibold border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'desktop'
                ? 'border-orange-500 text-orange-600 dark:text-orange-400'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Monitor className="w-4 h-4" /> Computer / PC
          </button>
          <button
            onClick={() => setActiveTab('matras')}
            className={`flex items-center gap-2 py-3 px-3 text-xs md:text-sm font-semibold border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'matras'
                ? 'border-orange-500 text-orange-600 dark:text-orange-400'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Sparkles className="w-4 h-4" /> मात्राएँ व चिह्न
          </button>
          <button
            onClick={() => setActiveTab('vowels')}
            className={`flex items-center gap-2 py-3 px-3 text-xs md:text-sm font-semibold border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'vowels'
                ? 'border-orange-500 text-orange-600 dark:text-orange-400'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <BookOpen className="w-4 h-4" /> स्वर (Vowels)
          </button>
          <button
            onClick={() => setActiveTab('consonants')}
            className={`flex items-center gap-2 py-3 px-3 text-xs md:text-sm font-semibold border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'consonants'
                ? 'border-orange-500 text-orange-600 dark:text-orange-400'
                : 'border-transparent text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            व्यंजन (Consonants)
          </button>
        </div>

        {/* Tab Contents */}
        <div className="p-6 overflow-y-auto space-y-4">
          {activeTab === 'mobile' && (
            <div className="space-y-4 text-sm text-slate-700 dark:text-slate-300">
              <div className="bg-orange-50 dark:bg-orange-950/30 border border-orange-200 dark:border-orange-900/50 rounded-xl p-4">
                <h4 className="font-bold text-orange-900 dark:text-orange-300 mb-1 flex items-center gap-2">
                  <Smartphone className="w-4 h-4" /> Android मोबाइल पर हिंदी टाइपिंग (Gboard)
                </h4>
                <p className="text-xs text-orange-800 dark:text-orange-300/90 leading-relaxed">
                  इस ऍप में वास्तविक देवनागरी यूनिकोड (Unicode) का उपयोग होता है, जो सभी Android फोन में स्वतः समर्थित है।
                </p>
              </div>

              <div className="space-y-3">
                <h5 className="font-semibold text-slate-900 dark:text-white">सरल चरण (Steps to Enable):</h5>
                <ol className="list-decimal list-inside space-y-2 text-xs md:text-sm leading-relaxed text-slate-600 dark:text-slate-400">
                  <li>अपने फ़ोन की <strong className="text-slate-800 dark:text-slate-200">Settings &gt; System &gt; Languages &amp; Input</strong> में जाएँ।</li>
                  <li><strong className="text-slate-800 dark:text-slate-200">Gboard (गूगल कीबोर्ड)</strong> चुनें और <strong className="text-slate-800 dark:text-slate-200">Languages</strong> पर टैप करें।</li>
                  <li><strong className="text-slate-800 dark:text-slate-200">Add Keyboard</strong> दबाकर <strong className="text-slate-800 dark:text-slate-200">Hindi (भारत)</strong> जोड़ें।</li>
                  <li>आप <em>हिंदी (वर्णमाला)</em> या <em>ABC &rarr; हिंदी (Hinglish Phonetic)</em> दोनों में से कोई भी चुन सकते हैं।</li>
                  <li>टाइपिंग बॉक्स में स्पेस बार पर देर तक दबाकर (Long Press) आसानी से भाषा बदलें।</li>
                </ol>
              </div>
            </div>
          )}

          {activeTab === 'desktop' && (
            <div className="space-y-4 text-sm text-slate-700 dark:text-slate-300">
              <div className="bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900/50 rounded-xl p-4">
                <h4 className="font-bold text-blue-900 dark:text-blue-300 mb-1 flex items-center gap-2">
                  <Monitor className="w-4 h-4" /> कंप्यूटर / लैपटॉप (Windows / Mac) पर हिंदी टाइपिंग
                </h4>
                <p className="text-xs text-blue-800 dark:text-blue-300/90">
                  यह ऍप्लिकेशन मानक यूनिकोड (Devanagari Unicode) पर कार्य करता है। किसी पुराने कृतीदेव (Kruti Dev) फॉन्ट की आवश्यकता नहीं है।
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs md:text-sm">
                <div className="p-3.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-800">
                  <h6 className="font-bold text-slate-900 dark:text-white mb-1.5">विकल्प 1: Hindi Phonetic</h6>
                  <p className="text-slate-600 dark:text-slate-400 text-xs leading-relaxed">
                    Windows 10/11 की Settings में <em>Hindi Phonetic</em> कीबोर्ड चालू करें। आप अंग्रेजी में <code className="bg-slate-200 dark:bg-slate-700 px-1 py-0.5 rounded">bharat</code> लिखेंगे और वह स्वतः <strong className="text-slate-900 dark:text-white">भारत</strong> बन जाएगा।
                  </p>
                </div>
                <div className="p-3.5 bg-slate-50 dark:bg-slate-800/50 rounded-xl border border-slate-200 dark:border-slate-800">
                  <h6 className="font-bold text-slate-900 dark:text-white mb-1.5">विकल्प 2: Hindi InScript</h6>
                  <p className="text-slate-600 dark:text-slate-400 text-xs leading-relaxed">
                    सरकारी परीक्षाओं (SSC, Railway, High Court) में आधिकारिक InScript कीबोर्ड मान्य है। इसे Windows में सीधे ऑन किया जा सकता है।
                  </p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'matras' && (
            <div className="space-y-3">
              <p className="text-xs text-slate-500 dark:text-slate-400">
                किसी भी मात्रा या चिह्न पर क्लिक करके कॉपी करें या टाइपिंग एरिया में तुरंत डालें:
              </p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {matras.map((m, i) => (
                  <button
                    key={i}
                    onClick={() => handleCopy(m.char)}
                    className="flex items-center justify-between p-2.5 bg-slate-50 dark:bg-slate-800/60 hover:bg-orange-50 dark:hover:bg-orange-950/40 border border-slate-200 dark:border-slate-800 hover:border-orange-300 dark:hover:border-orange-800 rounded-xl transition-all text-left group"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-hindi text-xl font-bold text-orange-600 dark:text-orange-400">
                          {m.char}
                        </span>
                        <span className="text-xs font-hindi text-slate-500">
                          ({m.example})
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-600 dark:text-slate-400 block mt-0.5">
                        {m.name}
                      </span>
                    </div>
                    {copiedChar === m.char ? (
                      <Check className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <Copy className="w-3.5 h-3.5 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'vowels' && (
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
              {vowels.map((v, i) => (
                <button
                  key={i}
                  onClick={() => handleCopy(v.char)}
                  className="flex flex-col items-center justify-center p-3 bg-slate-50 dark:bg-slate-800/60 hover:bg-orange-50 dark:hover:bg-orange-950/40 border border-slate-200 dark:border-slate-800 rounded-xl transition-all"
                >
                  <span className="font-hindi text-2xl font-bold text-slate-800 dark:text-slate-100">
                    {v.char}
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono mt-1">{v.label}</span>
                </button>
              ))}
            </div>
          )}

          {activeTab === 'consonants' && (
            <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
              {consonants.map((c, i) => (
                <button
                  key={i}
                  onClick={() => handleCopy(c)}
                  className="p-2.5 flex items-center justify-center bg-slate-50 dark:bg-slate-800/60 hover:bg-orange-50 dark:hover:bg-orange-950/40 border border-slate-200 dark:border-slate-800 rounded-xl transition-all"
                >
                  <span className="font-hindi text-xl font-bold text-slate-800 dark:text-slate-100">
                    {c}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
          <span>यूनिकोड आधारित - सभी मोबाइल और कंप्यूटर कीबोर्ड पर मान्य</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-900 text-white dark:bg-white dark:text-slate-900 rounded-lg font-medium hover:opacity-90"
          >
            समझ गया (Close)
          </button>
        </div>
      </div>
    </div>
  );
};
