import React, { useState } from 'react';
import { Keyboard, ArrowRight, ShieldCheck, Check, Sparkles, BookOpen, Clock, Award } from 'lucide-react';
import { Language, UserProfile } from '../types';

interface Props {
  onLogin: (user: UserProfile) => void;
}

export const LoginScreen: React.FC<Props> = ({ onLogin }) => {
  const [name, setName] = useState('');
  const [language, setLanguage] = useState<Language>('english');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('कृपया अपना नाम दर्ज करें / Please enter your name to continue');
      return;
    }

    const profile: UserProfile = {
      name: name.trim(),
      preferredLanguage: language,
      createdAt: new Date().toISOString(),
    };

    onLogin(profile);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white flex flex-col justify-center items-center p-4 sm:p-6 lg:p-8">
      {/* Background ambient glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-indigo-600/20 blur-[120px] rounded-full pointer-events-none" />

      <div className="relative z-10 w-full max-w-md">
        {/* Branding header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-tr from-indigo-500 via-blue-600 to-cyan-400 p-0.5 shadow-xl shadow-indigo-500/25 mb-4 animate-bounce-subtle">
            <div className="w-full h-full bg-slate-900/90 rounded-[14px] flex items-center justify-center">
              <Keyboard className="w-8 h-8 text-cyan-400" />
            </div>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-2">
            SAWAN TYPING
          </h1>
          <p className="text-indigo-200 text-sm font-medium">
            Hindi &amp; English Typing Practice
          </p>
          <p className="text-xs text-slate-400 mt-1">
            पेज देखकर टाइपिंग • लाइव स्पीड • शुद्धता विश्लेषण
          </p>
        </div>

        {/* Setup Card */}
        <div className="bg-slate-800/80 backdrop-blur-xl border border-slate-700/80 rounded-2xl p-6 sm:p-8 shadow-2xl">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Student Name */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                Student / Candidate Name <span className="text-rose-400">*</span>
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  if (error) setError('');
                }}
                placeholder="Enter your full name (e.g., Rohit Kumar)"
                autoFocus
                className="w-full px-4 py-3 bg-slate-900/90 border border-slate-600 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all"
              />
              {error && (
                <p className="text-xs text-rose-400 mt-1.5 font-medium animate-shake">
                  {error}
                </p>
              )}
            </div>

            {/* Language Selection */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                Select Typing Language <span className="text-rose-400">*</span>
              </label>
              <div className="grid grid-cols-2 gap-3">
                {/* Hindi Option */}
                <button
                  type="button"
                  onClick={() => setLanguage('hindi')}
                  className={`p-3.5 rounded-xl border-2 text-left transition-all relative flex flex-col justify-between ${
                    language === 'hindi'
                      ? 'border-orange-500 bg-orange-500/10 text-white shadow-md shadow-orange-500/10'
                      : 'border-slate-700 bg-slate-900/50 text-slate-400 hover:border-slate-600 hover:text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between w-full mb-1">
                    <span className="text-base font-bold font-hindi">हिंदी</span>
                    {language === 'hindi' && (
                      <span className="w-5 h-5 rounded-full bg-orange-500 text-white flex items-center justify-center text-xs">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </span>
                    )}
                  </div>
                  <span className="text-[11px] text-slate-400">
                    Hindi Unicode (Gboard/InScript)
                  </span>
                </button>

                {/* English Option */}
                <button
                  type="button"
                  onClick={() => setLanguage('english')}
                  className={`p-3.5 rounded-xl border-2 text-left transition-all relative flex flex-col justify-between ${
                    language === 'english'
                      ? 'border-indigo-500 bg-indigo-500/10 text-white shadow-md shadow-indigo-500/10'
                      : 'border-slate-700 bg-slate-900/50 text-slate-400 hover:border-slate-600 hover:text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between w-full mb-1">
                    <span className="text-base font-bold">English</span>
                    {language === 'english' && (
                      <span className="w-5 h-5 rounded-full bg-indigo-500 text-white flex items-center justify-center text-xs">
                        <Check className="w-3 h-3 stroke-[3]" />
                      </span>
                    )}
                  </div>
                  <span className="text-[11px] text-slate-400">
                    Standard QWERTY layout
                  </span>
                </button>
              </div>
            </div>

            {/* Start Button */}
            <button
              type="submit"
              className="w-full group py-3.5 px-6 rounded-xl bg-gradient-to-r from-indigo-600 via-blue-600 to-indigo-600 hover:from-indigo-500 hover:via-blue-500 hover:to-indigo-500 text-white font-bold text-sm shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all transform active:scale-[0.99]"
            >
              <span>START PRACTICE</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </form>

          {/* Privacy & Free notice */}
          <div className="mt-6 pt-5 border-t border-slate-700/60 flex items-center justify-center gap-2 text-xs text-slate-400">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>100% Free • No Payment • Saves Progress Locally</span>
          </div>
        </div>

        {/* Feature Badges below login */}
        <div className="mt-8 grid grid-cols-3 gap-2.5 text-center">
          <div className="p-2.5 rounded-xl bg-slate-800/40 border border-slate-700/40">
            <BookOpen className="w-4 h-4 text-indigo-400 mx-auto mb-1" />
            <span className="text-[11px] font-semibold text-slate-300 block">Page Typing</span>
            <span className="text-[10px] text-slate-500">Book/Paper Style</span>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-800/40 border border-slate-700/40">
            <Clock className="w-4 h-4 text-cyan-400 mx-auto mb-1" />
            <span className="text-[11px] font-semibold text-slate-300 block">Exam Timers</span>
            <span className="text-[10px] text-slate-500">SSC &amp; Court Tests</span>
          </div>
          <div className="p-2.5 rounded-xl bg-slate-800/40 border border-slate-700/40">
            <Award className="w-4 h-4 text-amber-400 mx-auto mb-1" />
            <span className="text-[11px] font-semibold text-slate-300 block">Deep Diff</span>
            <span className="text-[10px] text-slate-500">Exact Word Audit</span>
          </div>
        </div>
      </div>
    </div>
  );
};
