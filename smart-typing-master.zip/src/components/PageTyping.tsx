import React, { useState, useEffect, useRef } from 'react';
import { 
  ArrowLeft, 
  RotateCcw, 
  Pause, 
  Play, 
  CheckCircle2, 
  BookOpen, 
  Type, 
  HelpCircle, 
  PlusCircle, 
  Filter, 
  AlertCircle,
  Eye,
  EyeOff,
  Sparkles
} from 'lucide-react';
import { AppSettings, DifficultyLevel, EvaluationResult, Language, Passage, PassageLength } from '../types';
import { BUILT_IN_PASSAGES, getAllPassages, saveCustomPassage } from '../data/passages';
import { evaluateTyping, tokenizeWords } from '../utils/evaluation';
import { soundManager } from '../utils/sound';

interface Props {
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
  studentName: string;
  settings: AppSettings;
  onBack: () => void;
  onSubmitResult: (result: EvaluationResult) => void;
  onOpenHindiGuide: () => void;
}

export const PageTyping: React.FC<Props> = ({
  currentLanguage,
  onLanguageChange,
  studentName,
  settings,
  onBack,
  onSubmitResult,
  onOpenHindiGuide,
}) => {
  // Passages state
  const [passages, setPassages] = useState<Passage[]>(() => getAllPassages());
  const [selectedLevel, setSelectedLevel] = useState<DifficultyLevel | 'all'>('all');
  const [selectedLength, setSelectedLength] = useState<PassageLength | 'all'>('all');
  const [currentPassage, setCurrentPassage] = useState<Passage>(() => {
    const list = getAllPassages().filter(p => p.language === currentLanguage);
    return list[0] || BUILT_IN_PASSAGES[0];
  });

  // Custom passage modal state
  const [showCustomModal, setShowCustomModal] = useState(false);
  const [customTitle, setCustomTitle] = useState('');
  const [customContent, setCustomContent] = useState('');

  // Typing session state
  const [typedText, setTypedText] = useState('');
  const [isTypingStarted, setIsTypingStarted] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [showRestartConfirm, setShowRestartConfirm] = useState(false);
  const [showEmptySubmitNotice, setShowEmptySubmitNotice] = useState(false);
  const [mobilePassageExpanded, setMobilePassageExpanded] = useState(true);

  // Font size setting
  const [fontSize, setFontSize] = useState<'sm' | 'md' | 'lg' | 'xl'>(settings.fontSize || 'md');

  // Precise timing refs
  const startTimeRef = useRef<number | null>(null);
  const accumulatedMsRef = useRef<number>(0);
  const timerIntervalRef = useRef<number | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Update current passage when language changes
  useEffect(() => {
    const matching = passages.filter(p => p.language === currentLanguage);
    if (matching.length > 0 && currentPassage.language !== currentLanguage) {
      setCurrentPassage(matching[0]);
      resetSession();
    }
  }, [currentLanguage, passages]);

  // Clean timer on unmount
  useEffect(() => {
    return () => {
      if (timerIntervalRef.current) {
        window.clearInterval(timerIntervalRef.current);
      }
    };
  }, []);

  // Timer runner using real timestamps (Date.now())
  const startTimerRunner = () => {
    if (timerIntervalRef.current) window.clearInterval(timerIntervalRef.current);
    startTimeRef.current = Date.now();

    timerIntervalRef.current = window.setInterval(() => {
      if (startTimeRef.current) {
        const now = Date.now();
        const sessionMs = accumulatedMsRef.current + (now - startTimeRef.current);
        const totalSecs = Math.floor(sessionMs / 1000);
        setElapsedSeconds(totalSecs);
      }
    }, 200);
  };

  const pauseTimer = () => {
    if (timerIntervalRef.current) {
      window.clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }
    if (startTimeRef.current) {
      accumulatedMsRef.current += Date.now() - startTimeRef.current;
      startTimeRef.current = null;
    }
    setIsPaused(true);
  };

  const resumeTimer = () => {
    setIsPaused(false);
    startTimerRunner();
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  // Reset current session
  const resetSession = () => {
    if (timerIntervalRef.current) {
      window.clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }
    startTimeRef.current = null;
    accumulatedMsRef.current = 0;
    setElapsedSeconds(0);
    setIsTypingStarted(false);
    setIsPaused(false);
    setTypedText('');
    setShowRestartConfirm(false);
    setShowEmptySubmitNotice(false);
    if (textareaRef.current) {
      textareaRef.current.focus();
    }
  };

  const handleRestartClick = () => {
    if (isTypingStarted && typedText.trim().length > 0) {
      setShowRestartConfirm(true);
    } else {
      resetSession();
    }
  };

  // Typing Input Handler
  const handleTypingChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value;

    // Start timer on FIRST typed character
    if (!isTypingStarted && value.length > 0) {
      setIsTypingStarted(true);
      startTimerRunner();
    }

    setTypedText(value);
    soundManager.playKeyClick();
  };

  // Live calculations
  const totalCharsTyped = typedText.length;
  const currentWords = tokenizeWords(typedText);
  const totalWordsTyped = currentWords.length;
  const minutes = Math.max(elapsedSeconds / 60, 0.05);

  // Live Gross WPM
  const liveGrossWPM = isTypingStarted && elapsedSeconds > 0
    ? Math.round((totalCharsTyped / 5) / minutes)
    : 0;

  // Live CPM
  const liveCPM = isTypingStarted && elapsedSeconds > 0
    ? Math.round(totalCharsTyped / minutes)
    : 0;

  // Live progress %
  const progressPct = currentPassage.charCount > 0
    ? Math.min(100, Math.round((totalCharsTyped / currentPassage.charCount) * 100))
    : 0;

  // Format elapsed time mm:ss
  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Submit test
  const handleSubmit = () => {
    if (!typedText.trim()) {
      setShowEmptySubmitNotice(true);
      return;
    }

    // Stop timer
    if (timerIntervalRef.current) window.clearInterval(timerIntervalRef.current);
    const finalSecs = Math.max(elapsedSeconds, 1);

    // Run accurate sequence alignment evaluation
    const evaluation = evaluateTyping({
      referenceText: currentPassage.content,
      typedText: typedText,
      durationSeconds: finalSecs,
      language: currentPassage.language,
      mode: 'page_typing',
      passageId: currentPassage.id,
      passageTitle: currentPassage.title,
      studentName: studentName || 'Student',
      strictWhitespace: settings.strictWhitespace,
    });

    soundManager.playSuccessChime();
    onSubmitResult(evaluation);
  };

  // Filter passages
  const filteredPassages = passages.filter(p => {
    if (p.language !== currentLanguage) return false;
    if (selectedLevel !== 'all' && p.level !== selectedLevel) return false;
    if (selectedLength !== 'all' && p.lengthCategory !== selectedLength) return false;
    return true;
  });

  // Save custom passage
  const handleCreateCustomPassage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customTitle.trim() || !customContent.trim()) return;

    const words = tokenizeWords(customContent);
    const newPassage = saveCustomPassage({
      title: customTitle.trim(),
      language: currentLanguage,
      level: 'intermediate',
      lengthCategory: words.length < 80 ? 'short' : words.length < 200 ? 'medium' : 'long',
      content: customContent.trim(),
      wordCount: words.length,
      charCount: customContent.trim().length,
      source: 'Custom Exam Passage',
    });

    setPassages(getAllPassages());
    setCurrentPassage(newPassage);
    setShowCustomModal(false);
    setCustomTitle('');
    setCustomContent('');
    resetSession();
  };

  // Font size classes
  const fontSizes = {
    sm: 'text-sm leading-relaxed',
    md: 'text-base leading-relaxed',
    lg: 'text-lg leading-loose',
    xl: 'text-xl leading-loose',
  };

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-6 space-y-4">
      {/* Top Header Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-3 sm:p-4 shadow-xs flex flex-wrap items-center justify-between gap-3">
        {/* Left: Back & Passage info */}
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
            title="Back to Dashboard"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-extrabold text-slate-900 dark:text-white truncate max-w-[240px] sm:max-w-md">
                {currentPassage.title}
              </h2>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                currentPassage.language === 'hindi'
                  ? 'bg-orange-100 text-orange-700 dark:bg-orange-950/70 dark:text-orange-400'
                  : 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950/70 dark:text-indigo-400'
              }`}>
                {currentPassage.language === 'hindi' ? 'हिंदी' : 'English'}
              </span>
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              {currentPassage.wordCount} words • {currentPassage.charCount} characters • {currentPassage.source || 'Official Practice'}
            </p>
          </div>
        </div>

        {/* Center: Live Timer Badge */}
        <div className="flex items-center gap-3 bg-slate-50 dark:bg-slate-800/80 px-4 py-2 rounded-2xl border border-slate-200 dark:border-slate-700">
          <div className="flex flex-col items-center">
            <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
              {isTypingStarted ? (isPaused ? 'PAUSED' : 'ELAPSED') : 'READY'}
            </span>
            <span className="font-mono text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
              {formatTime(elapsedSeconds)}
            </span>
          </div>

          {/* Pause / Resume button */}
          {isTypingStarted && (
            <button
              onClick={isPaused ? resumeTimer : pauseTimer}
              className={`p-2 rounded-xl text-xs font-bold transition-colors ${
                isPaused
                  ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                  : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200 hover:bg-slate-300'
              }`}
              title={isPaused ? 'Resume Timer' : 'Pause Timer'}
            >
              {isPaused ? <Play className="w-4 h-4 fill-current" /> : <Pause className="w-4 h-4" />}
            </button>
          )}

          {/* Restart button */}
          <button
            onClick={handleRestartClick}
            className="p-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:text-slate-900 hover:bg-slate-300 dark:hover:bg-slate-600 transition-colors"
            title="Restart Practice"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Right Controls: Font size, Hindi guide, Language toggle */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Font Size Selector */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 rounded-xl p-0.5 border border-slate-200 dark:border-slate-700">
            {(['sm', 'md', 'lg', 'xl'] as const).map((s) => (
              <button
                key={s}
                onClick={() => setFontSize(s)}
                className={`px-2 py-1 text-[11px] font-bold rounded-lg transition-colors ${
                  fontSize === s
                    ? 'bg-white dark:bg-slate-700 text-indigo-600 dark:text-indigo-400 shadow-xs'
                    : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'
                }`}
              >
                {s.toUpperCase()}
              </button>
            ))}
          </div>

          {/* Hindi Guide button */}
          {currentLanguage === 'hindi' && (
            <button
              onClick={onOpenHindiGuide}
              className="px-2.5 py-1.5 bg-orange-50 dark:bg-orange-950/40 text-orange-600 dark:text-orange-400 border border-orange-200 dark:border-orange-800 rounded-xl text-xs font-semibold flex items-center gap-1 hover:bg-orange-100"
              title="देवनागरी कीबोर्ड सहायक"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Hindi Guide</span>
            </button>
          )}

          {/* Language Toggle */}
          <button
            onClick={() => onLanguageChange(currentLanguage === 'hindi' ? 'english' : 'hindi')}
            className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
          >
            {currentLanguage === 'hindi' ? 'Switch to English' : 'हिंदी मोड'}
          </button>
        </div>
      </div>

      {/* Passage Selector Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-3.5 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5 text-indigo-500" /> Passages:
          </span>

          {/* Difficulty pills */}
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
            {(['all', 'beginner', 'intermediate', 'advanced', 'exam'] as const).map((lvl) => (
              <button
                key={lvl}
                onClick={() => setSelectedLevel(lvl)}
                className={`px-2.5 py-1 rounded-lg capitalize font-medium transition-colors ${
                  selectedLevel === lvl
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                {lvl === 'exam' ? 'Exam Papers' : lvl}
              </button>
            ))}
          </div>

          {/* Length pills */}
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
            {(['all', 'short', 'medium', 'long'] as const).map((len) => (
              <button
                key={len}
                onClick={() => setSelectedLength(len)}
                className={`px-2.5 py-1 rounded-lg capitalize font-medium transition-colors ${
                  selectedLength === len
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                {len}
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Passage Quick Dropdown */}
          <select
            value={currentPassage.id}
            onChange={(e) => {
              const p = passages.find(item => item.id === e.target.value);
              if (p) {
                setCurrentPassage(p);
                resetSession();
              }
            }}
            className="px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-medium text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500 focus:outline-none max-w-[200px] truncate"
          >
            {filteredPassages.map((p) => (
              <option key={p.id} value={p.id}>
                {p.title} ({p.wordCount} words)
              </option>
            ))}
          </select>

          {/* Custom passage creator */}
          <button
            onClick={() => setShowCustomModal(true)}
            className="flex items-center gap-1 px-3 py-1.5 bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800 rounded-xl font-bold hover:bg-indigo-100"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>Custom Passage</span>
          </button>
        </div>
      </div>

      {/* Restart Confirmation Banner if user typed something */}
      {showRestartConfirm && (
        <div className="p-4 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 rounded-2xl flex items-center justify-between gap-4 animate-in fade-in">
          <div className="flex items-center gap-2.5 text-xs sm:text-sm text-amber-900 dark:text-amber-200">
            <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
            <span>
              <strong>पुनः आरंभ करें (Restart Test)?</strong> आपका वर्तमान टाइप किया हुआ टेक्स्ट साफ़ हो जाएगा।
            </span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={resetSession}
              className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold"
            >
              हाँ, पुनः आरंभ करें
            </button>
            <button
              onClick={() => setShowRestartConfirm(false)}
              className="px-3 py-1.5 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-semibold"
            >
              रद्द करें
            </button>
          </div>
        </div>
      )}

      {/* Empty Submit warning */}
      {showEmptySubmitNotice && (
        <div className="p-3.5 bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800 rounded-2xl flex items-center justify-between text-xs text-rose-800 dark:text-rose-200 animate-shake">
          <span>
            टाइपिंग बॉक्स खाली है! मूल्यांकन के लिए कृपया गद्यांश देखकर कुछ टाइप करें।
          </span>
          <button
            onClick={() => setShowEmptySubmitNotice(false)}
            className="font-bold underline ml-2"
          >
            बंद करें
          </button>
        </div>
      )}

      {/* Main Dual Area: Split screen on Desktop, Stacked on Mobile */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* LEFT / TOP PANEL: The Reference Page Display */}
        <div className="bg-amber-50/50 dark:bg-slate-900 border-2 border-amber-200/70 dark:border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xs flex flex-col justify-between relative overflow-hidden">
          {/* Realistic Book Page Header Line */}
          <div className="border-b border-amber-200 dark:border-slate-800 pb-3 mb-4 flex items-center justify-between text-xs text-amber-900/70 dark:text-slate-400">
            <div className="flex items-center gap-2 font-mono">
              <BookOpen className="w-4 h-4 text-amber-600 dark:text-amber-500" />
              <span className="font-semibold tracking-wider uppercase">REFERENCE PASSAGE (पन्ना / प्रश्नपत्र)</span>
            </div>
            {/* Mobile collapse / expand toggle */}
            <button
              onClick={() => setMobilePassageExpanded(!mobilePassageExpanded)}
              className="lg:hidden flex items-center gap-1 font-bold text-indigo-600 dark:text-indigo-400"
            >
              {mobilePassageExpanded ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              <span>{mobilePassageExpanded ? 'छोटा करें (Collapse)' : 'गद्यांश देखें (Expand)'}</span>
            </button>
          </div>

          {/* Passage Content formatted like a crisp paper/book */}
          {mobilePassageExpanded && (
            <div 
              tabIndex={0}
              aria-label="Reference passage"
              className={`max-h-[300px] lg:max-h-[460px] overflow-y-auto pr-2 select-text text-slate-800 dark:text-slate-200 font-normal focus:outline-none focus:ring-1 focus:ring-indigo-400/40 rounded-lg ${
                currentPassage.language === 'hindi' ? 'font-hindi' : ''
              } ${fontSizes[fontSize]}`}
            >
              {currentPassage.content}
            </div>
          )}

          {/* Reference Page Footnote */}
          <div className="mt-4 pt-3 border-t border-amber-200/60 dark:border-slate-800 flex items-center justify-between text-[11px] text-amber-800/80 dark:text-slate-500">
            <span>शब्द संख्या: {currentPassage.wordCount} • वर्ण: {currentPassage.charCount}</span>
            <span className="italic">हूबहू टाइपिंग अपेक्षित है</span>
          </div>
        </div>

        {/* RIGHT / BOTTOM PANEL: The Student Typing Area */}
        <div className="bg-white dark:bg-slate-900 border-2 border-indigo-200 dark:border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xs flex flex-col justify-between relative">
          {/* Typing Area Header */}
          <div className="border-b border-slate-200 dark:border-slate-800 pb-3 mb-3 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <div className="flex items-center gap-2">
              <Type className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span className="font-bold text-slate-800 dark:text-slate-200">
                TYPING AREA (यहाँ टाइप करें)
              </span>
            </div>
            <span className="text-[11px]">
              {isTypingStarted ? 'पहला अक्षर दबाते ही समय शुरू हो चुका है' : 'पहला अक्षर टाइप करते ही टाइमर शुरू होगा'}
            </span>
          </div>

          {/* Text Area */}
          <div className="relative flex-1">
            <textarea
              ref={textareaRef}
              value={typedText}
              onChange={handleTypingChange}
              disabled={isPaused}
              placeholder={
                currentPassage.language === 'hindi'
                  ? 'यहाँ टाइपिंग शुरू करें... (पहला अक्षर दबाते ही टाइमर स्वतः चालू होगा)'
                  : 'Start typing the passage here... (Timer begins automatically upon your first keystroke)'
              }
              spellCheck={false}
              autoCapitalize="off"
              autoCorrect="off"
              autoComplete="off"
              className={`w-full h-[280px] lg:h-[390px] p-3.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all resize-none ${
                currentPassage.language === 'hindi' ? 'font-hindi' : ''
              } ${fontSizes[fontSize]}`}
            />

            {/* Paused Overlay */}
            {isPaused && (
              <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-xs rounded-xl flex flex-col items-center justify-center text-white gap-3 animate-in fade-in">
                <span className="text-base font-bold">टाइपिंग रुकी हुई है (PAUSED)</span>
                <button
                  onClick={resumeTimer}
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-lg flex items-center gap-2"
                >
                  <Play className="w-4 h-4 fill-current" />
                  <span>Resume Practice</span>
                </button>
              </div>
            )}
          </div>

          {/* Live Progress Bar */}
          <div className="mt-3">
            <div className="flex items-center justify-between text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
              <span>Passage Completion</span>
              <span>{progressPct}% ({totalCharsTyped}/{currentPassage.charCount} chars)</span>
            </div>
            <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-indigo-500 to-emerald-500 transition-all duration-200"
                style={{ width: `${progressPct}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Live Statistics Ribbon */}
      <div className="bg-slate-900 text-white rounded-2xl p-4 shadow-lg grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4 text-center">
        <div>
          <span className="text-[10px] uppercase font-bold text-slate-400 block">Elapsed Time</span>
          <span className="font-mono text-xl sm:text-2xl font-black text-amber-400">
            {formatTime(elapsedSeconds)}
          </span>
        </div>
        <div>
          <span className="text-[10px] uppercase font-bold text-slate-400 block">Words Typed</span>
          <span className="font-mono text-xl sm:text-2xl font-black text-white">
            {totalWordsTyped}
          </span>
        </div>
        <div>
          <span className="text-[10px] uppercase font-bold text-slate-400 block">Characters</span>
          <span className="font-mono text-xl sm:text-2xl font-black text-cyan-400">
            {totalCharsTyped}
          </span>
        </div>
        <div>
          <span className="text-[10px] uppercase font-bold text-slate-400 block">Gross Speed</span>
          <span className="font-mono text-xl sm:text-2xl font-black text-indigo-400">
            {liveGrossWPM} <span className="text-xs font-bold text-slate-400">WPM</span>
          </span>
        </div>
        <div>
          <span className="text-[10px] uppercase font-bold text-slate-400 block">Keystrokes / Min</span>
          <span className="font-mono text-xl sm:text-2xl font-black text-emerald-400">
            {liveCPM} <span className="text-xs font-bold text-slate-400">CPM</span>
          </span>
        </div>
        <div className="col-span-2 sm:col-span-1">
          <span className="text-[10px] uppercase font-bold text-slate-400 block">Live Status</span>
          <span className="text-xs font-bold px-2 py-1 rounded bg-slate-800 text-slate-300 inline-block mt-1">
            {isTypingStarted ? (isPaused ? 'Paused' : 'Active') : 'Waiting Keystroke'}
          </span>
        </div>
      </div>

      {/* SUBMIT BUTTON SECTION */}
      <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="text-xs text-slate-500 dark:text-slate-400">
          * सबमिट करने पर टाइमर बंद होगा और शब्द-दर-शब्द विस्तृत परिणाम स्क्रीन दिखाई जाएगी।
        </div>
        <button
          onClick={handleSubmit}
          className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-extrabold text-base rounded-2xl shadow-lg shadow-emerald-600/30 flex items-center justify-center gap-2 transform active:scale-[0.99] transition-all"
        >
          <CheckCircle2 className="w-5 h-5" />
          <span>SUBMIT TEST (मूल्यांकन करें)</span>
        </button>
      </div>

      {/* Custom Passage Modal */}
      {showCustomModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-lg w-full p-6 border border-slate-200 dark:border-slate-800">
            <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-1">
              Add Custom Practice Passage
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              अपनी परीक्षा या पुस्तक का कोई भी गद्यांश यहाँ पेस्ट करें
            </p>

            <form onSubmit={handleCreateCustomPassage} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Passage Title
                </label>
                <input
                  type="text"
                  value={customTitle}
                  onChange={(e) => setCustomTitle(e.target.value)}
                  placeholder="e.g., Allahabad High Court Clerk Sample 2024"
                  required
                  className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none dark:text-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Passage Content (Text)
                </label>
                <textarea
                  value={customContent}
                  onChange={(e) => setCustomContent(e.target.value)}
                  placeholder="Paste or type the custom paragraph here in Hindi or English..."
                  rows={6}
                  required
                  className={`w-full p-3.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none dark:text-white ${
                    currentLanguage === 'hindi' ? 'font-hindi' : ''
                  }`}
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCustomModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-indigo-600 text-white rounded-xl text-xs font-bold hover:bg-indigo-700"
                >
                  Save &amp; Start Practice
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
