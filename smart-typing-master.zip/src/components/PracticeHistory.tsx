import React, { useState } from 'react';
import { 
  History, 
  Search, 
  Filter, 
  Trash2, 
  Download, 
  ArrowLeft, 
  Award, 
  Clock, 
  Zap, 
  CheckCircle, 
  AlertCircle,
  TrendingUp,
  FileText
} from 'lucide-react';
import { EvaluationResult, Language, PracticeMode } from '../types';
import { deleteHistoryItem, clearAllHistory, exportDataAsJson } from '../utils/storage';

interface Props {
  history: EvaluationResult[];
  onSelectResult: (result: EvaluationResult) => void;
  onRefreshHistory: () => void;
  onBack: () => void;
}

export const PracticeHistory: React.FC<Props> = ({
  history,
  onSelectResult,
  onRefreshHistory,
  onBack,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [langFilter, setLangFilter] = useState<Language | 'all'>('all');
  const [modeFilter, setModeFilter] = useState<PracticeMode | 'all'>('all');
  const [sortBy, setSortBy] = useState<'date_desc' | 'date_asc' | 'speed_desc' | 'accuracy_desc'>('date_desc');
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [showClearAllConfirm, setShowClearAllConfirm] = useState(false);

  // Filter & Sort
  const filtered = history.filter(item => {
    if (langFilter !== 'all' && item.language !== langFilter) return false;
    if (modeFilter !== 'all' && item.mode !== modeFilter) return false;
    if (searchTerm.trim()) {
      const q = searchTerm.toLowerCase();
      const matchTitle = item.passageTitle?.toLowerCase().includes(q);
      const matchName = item.studentName?.toLowerCase().includes(q);
      if (!matchTitle && !matchName) return false;
    }
    return true;
  });

  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === 'date_desc') return b.timestamp - a.timestamp;
    if (sortBy === 'date_asc') return a.timestamp - b.timestamp;
    if (sortBy === 'speed_desc') return b.netWPM - a.netWPM;
    if (sortBy === 'accuracy_desc') return (b.accuracyPercentage || 0) - (a.accuracyPercentage || 0);
    return 0;
  });

  const handleDeleteItem = (id: string) => {
    deleteHistoryItem(id);
    setDeleteId(null);
    onRefreshHistory();
  };

  const handleClearAll = () => {
    clearAllHistory();
    setShowClearAllConfirm(false);
    onRefreshHistory();
  };

  const handleExport = () => {
    const jsonStr = exportDataAsJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Smart_Typing_History_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Prepare chart points for historical speed & accuracy (chronological order)
  const chartData = [...history]
    .sort((a, b) => a.timestamp - b.timestamp)
    .slice(-15); // latest 15 points

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="p-2 rounded-xl bg-purple-50 dark:bg-purple-950/60 text-purple-600 dark:text-purple-400">
                <History className="w-5 h-5" />
              </span>
              <div>
                <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
                  Practice History (अभ्यास इतिहास)
                </h1>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Total {history.length} completed sessions logged locally
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Global actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-50 shadow-xs"
          >
            <Download className="w-3.5 h-3.5 text-indigo-500" />
            <span>Export Backup</span>
          </button>

          {history.length > 0 && (
            <button
              onClick={() => setShowClearAllConfirm(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/40 text-xs font-semibold text-rose-600 dark:text-rose-400 hover:bg-rose-100"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear History</span>
            </button>
          )}
        </div>
      </div>

      {/* Clear All Confirmation Dialog */}
      {showClearAllConfirm && (
        <div className="p-4 bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800 rounded-2xl flex items-center justify-between gap-4 animate-in fade-in">
          <div className="flex items-center gap-2 text-xs sm:text-sm text-rose-900 dark:text-rose-200">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
            <span>
              <strong>सभी इतिहास हटाएं (Clear All History)?</strong> यह क्रिया वापस नहीं ली जा सकती।
            </span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleClearAll}
              className="px-3.5 py-1.5 bg-rose-600 text-white rounded-xl text-xs font-bold hover:bg-rose-700"
            >
              हाँ, सब हटाएं
            </button>
            <button
              onClick={() => setShowClearAllConfirm(false)}
              className="px-3.5 py-1.5 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-semibold"
            >
              रद्द करें
            </button>
          </div>
        </div>
      )}

      {/* Performance Trends Chart (SVG) */}
      {chartData.length > 1 && (
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-indigo-500" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Typing Speed &amp; Accuracy Progress Trend
              </h3>
            </div>
            <div className="flex items-center gap-4 text-xs font-medium">
              <span className="flex items-center gap-1.5 text-indigo-600 dark:text-indigo-400">
                <span className="w-3 h-0.5 bg-indigo-600 inline-block" /> Speed (WPM)
              </span>
              <span className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400">
                <span className="w-3 h-0.5 bg-emerald-600 inline-block" /> Accuracy (%)
              </span>
            </div>
          </div>

          {/* Responsive SVG Chart */}
          <div className="w-full h-44 pt-2">
            <svg className="w-full h-full overflow-visible" viewBox="0 0 500 130" preserveAspectRatio="none">
              {/* Grid Lines */}
              <line x1="0" y1="20" x2="500" y2="20" stroke="#94a3b8" strokeDasharray="3 3" strokeOpacity="0.2" />
              <line x1="0" y1="65" x2="500" y2="65" stroke="#94a3b8" strokeDasharray="3 3" strokeOpacity="0.2" />
              <line x1="0" y1="110" x2="500" y2="110" stroke="#94a3b8" strokeDasharray="3 3" strokeOpacity="0.2" />

              {/* Speed Line Points */}
              {(() => {
                const maxSpeed = Math.max(...chartData.map(d => d.netWPM), 50);
                const points = chartData.map((d, i) => {
                  const x = (i / (chartData.length - 1)) * 480 + 10;
                  const y = 110 - (d.netWPM / maxSpeed) * 90;
                  return `${x},${y}`;
                }).join(' ');

                const accPoints = chartData.map((d, i) => {
                  const x = (i / (chartData.length - 1)) * 480 + 10;
                  const y = 110 - ((d.accuracyPercentage || 0) / 100) * 90;
                  return `${x},${y}`;
                }).join(' ');

                return (
                  <>
                    <polyline
                      fill="none"
                      stroke="#6366f1"
                      strokeWidth="2.5"
                      points={points}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    <polyline
                      fill="none"
                      stroke="#10b981"
                      strokeWidth="2"
                      strokeDasharray="4 2"
                      points={accPoints}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                    {chartData.map((d, i) => {
                      const x = (i / (chartData.length - 1)) * 480 + 10;
                      const y = 110 - (d.netWPM / maxSpeed) * 90;
                      return (
                        <circle key={i} cx={x} cy={y} r="3.5" fill="#4f46e5" stroke="#fff" strokeWidth="1.5" />
                      );
                    })}
                  </>
                );
              })()}
            </svg>
          </div>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* Search */}
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by passage name..."
            className="w-full pl-9 pr-3.5 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none dark:text-white"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Language filter */}
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
            {(['all', 'hindi', 'english'] as const).map((l) => (
              <button
                key={l}
                onClick={() => setLangFilter(l)}
                className={`px-2.5 py-1 rounded-lg font-medium capitalize ${
                  langFilter === l
                    ? 'bg-indigo-600 text-white font-bold'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {l === 'hindi' ? 'हिन्दी' : l}
              </button>
            ))}
          </div>

          {/* Mode filter */}
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
            {(['all', 'page_typing', 'typing_test', 'text_practice'] as const).map((m) => (
              <button
                key={m}
                onClick={() => setModeFilter(m)}
                className={`px-2.5 py-1 rounded-lg font-medium ${
                  modeFilter === m
                    ? 'bg-indigo-600 text-white font-bold'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                {m === 'page_typing' ? 'Page' : m === 'typing_test' ? 'Exam' : m === 'text_practice' ? 'Free' : 'All'}
              </button>
            ))}
          </div>

          {/* Sort Dropdown */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
            className="px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-medium text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
          >
            <option value="date_desc">Newest First</option>
            <option value="date_asc">Oldest First</option>
            <option value="speed_desc">Highest Speed</option>
            <option value="accuracy_desc">Highest Accuracy</option>
          </select>
        </div>
      </div>

      {/* History Cards List */}
      {sorted.length === 0 ? (
        <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 space-y-2">
          <FileText className="w-10 h-10 text-slate-300 mx-auto" />
          <h4 className="text-base font-bold text-slate-800 dark:text-slate-200">
            कोई इतिहास प्रविष्टि नहीं मिली (No Records Found)
          </h4>
          <p className="text-xs text-slate-500">
            {history.length === 0
              ? 'आपने अभी तक कोई टेस्ट सबमिट नहीं किया है। पेज देखकर अभ्यास शुरू करें!'
              : 'दिए गए फ़िल्टर के अनुसार कोई परिणाम नहीं मिला।'}
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {sorted.map((item) => (
            <div
              key={item.id}
              className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs hover:shadow-md transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              {/* Left Item Details */}
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                    {item.passageTitle}
                  </h4>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                    item.language === 'hindi'
                      ? 'bg-orange-100 text-orange-700 dark:bg-orange-950 dark:text-orange-400'
                      : 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-400'
                  }`}>
                    {item.language}
                  </span>
                  <span className="px-2 py-0.5 rounded text-[10px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 capitalize">
                    {item.mode.replace('_', ' ')}
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
                  <span>Candidate: <strong>{item.studentName}</strong></span>
                  <span>• {item.date}</span>
                  <span>• Duration: {item.timeFormatted}</span>
                  <span>• Words: {item.totalWordsTyped}</span>
                </div>
              </div>

              {/* Right Metrics & Actions */}
              <div className="flex items-center gap-4 self-end sm:self-center">
                {/* Score Pill */}
                <div className="flex items-center gap-3 text-right">
                  <div>
                    <span className="text-xs text-slate-400 block font-medium">Net Speed</span>
                    <span className="font-mono text-base font-black text-indigo-600 dark:text-indigo-400">
                      {item.netWPM} WPM
                    </span>
                  </div>
                  {!item.isFreeTyping && (
                    <div>
                      <span className="text-xs text-slate-400 block font-medium">Accuracy</span>
                      <span className="font-mono text-base font-black text-emerald-600 dark:text-emerald-400">
                        {item.accuracyPercentage}%
                      </span>
                    </div>
                  )}
                </div>

                {/* View Details Button */}
                <button
                  onClick={() => onSelectResult(item)}
                  className="px-3.5 py-2 bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 text-indigo-700 dark:text-indigo-300 font-bold text-xs rounded-xl transition-colors"
                >
                  View Scorecard
                </button>

                {/* Delete button */}
                {deleteId === item.id ? (
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleDeleteItem(item.id)}
                      className="px-2 py-1 bg-rose-600 text-white text-[11px] font-bold rounded-lg"
                    >
                      Confirm
                    </button>
                    <button
                      onClick={() => setDeleteId(null)}
                      className="px-2 py-1 bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 text-[11px] rounded-lg"
                    >
                      No
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setDeleteId(item.id)}
                    className="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-xl transition-colors"
                    title="Delete session"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
