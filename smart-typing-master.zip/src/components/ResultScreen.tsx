import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { 
  Award, 
  RotateCcw, 
  ArrowLeft, 
  Printer, 
  Download, 
  BookOpen, 
  History, 
  CheckCircle, 
  XCircle, 
  Clock, 
  Zap, 
  AlertTriangle,
  Info,
  ChevronDown,
  ChevronUp
} from 'lucide-react';
import { EvaluationResult } from '../types';
import { exportResultToPDF } from '../utils/pdfExport';

interface Props {
  result: EvaluationResult;
  onTryAgain: () => void;
  onChooseNewPassage: () => void;
  onViewHistory: () => void;
  onBackToDashboard: () => void;
}

export const ResultScreen: React.FC<Props> = ({
  result,
  onTryAgain,
  onChooseNewPassage,
  onViewHistory,
  onBackToDashboard,
}) => {
  const [showFormulaModal, setShowFormulaModal] = useState(false);
  const [errorFilter, setErrorFilter] = useState<'all' | 'spelling' | 'missing_word' | 'extra_word' | 'punctuation'>('all');
  const [showFullDiff, setShowFullDiff] = useState(true);

  // Trigger celebration confetti for good scores
  useEffect(() => {
    if (result.accuracyPercentage >= 85 && result.netWPM >= 25) {
      confetti({
        particleCount: 70,
        spread: 60,
        origin: { y: 0.6 }
      });
    }
  }, [result]);

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPDF = () => {
    exportResultToPDF(result);
  };

  // Filter errors
  const filteredErrors = result.errors.filter(err => {
    if (errorFilter === 'all') return true;
    return err.type === errorFilter;
  });

  const gradeColors = {
    Excellent: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/30',
    'Very Good': 'bg-blue-500/10 text-blue-600 dark:text-blue-400 border-blue-500/30',
    Good: 'bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 border-indigo-500/30',
    Improving: 'bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/30',
    Beginner: 'bg-slate-500/10 text-slate-600 dark:text-slate-400 border-slate-500/30',
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
      {/* Title & Actions Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
              <Award className="w-5 h-5" />
            </span>
            <div>
              <h1 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">
                TYPING TEST RESULT (परीक्षा परिणाम)
              </h1>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Candidate: <strong className="text-slate-800 dark:text-slate-200">{result.studentName}</strong> • {result.date} • {result.passageTitle}
              </p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2 no-print">
          <button
            onClick={handleDownloadPDF}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition-all"
            title="Download Official PDF Report"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download PDF</span>
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 text-xs font-semibold rounded-xl transition-all"
            title="Print Scorecard"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print</span>
          </button>
          <button
            onClick={() => setShowFormulaModal(true)}
            className="flex items-center gap-1 px-3 py-2 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 rounded-xl text-xs font-medium hover:bg-slate-200"
          >
            <Info className="w-3.5 h-3.5 text-indigo-500" />
            <span className="hidden sm:inline">Scoring Formula</span>
          </button>
        </div>
      </div>

      {/* TOP SUMMARY CARDS */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* Net Speed */}
        <div className="p-4 rounded-2xl bg-indigo-600 text-white shadow-lg shadow-indigo-600/20 flex flex-col justify-between">
          <div className="flex items-center justify-between opacity-80 text-xs font-bold uppercase">
            <span>Net Speed</span>
            <Zap className="w-4 h-4" />
          </div>
          <div className="my-1">
            <span className="text-3xl font-black">{result.netWPM}</span>
            <span className="text-xs font-bold ml-1 opacity-90">WPM</span>
          </div>
          <div className="text-[11px] opacity-80">
            Gross: {result.grossWPM} WPM
          </div>
        </div>

        {/* Accuracy */}
        <div className="p-4 rounded-2xl bg-emerald-600 text-white shadow-lg shadow-emerald-600/20 flex flex-col justify-between">
          <div className="flex items-center justify-between opacity-80 text-xs font-bold uppercase">
            <span>Accuracy</span>
            <CheckCircle className="w-4 h-4" />
          </div>
          <div className="my-1">
            <span className="text-3xl font-black">{result.accuracyPercentage}</span>
            <span className="text-xs font-bold ml-1 opacity-90">%</span>
          </div>
          <div className="text-[11px] opacity-80">
            Error: {result.errorPercentage}%
          </div>
        </div>

        {/* Total Time */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-bold uppercase">
            <span>Total Time</span>
            <Clock className="w-4 h-4 text-cyan-500" />
          </div>
          <div className="my-1">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{result.timeFormatted}</span>
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400">
            {result.durationSeconds} seconds
          </div>
        </div>

        {/* Words Typed */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-bold uppercase">
            <span>Words Typed</span>
            <BookOpen className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="my-1">
            <span className="text-2xl font-black text-slate-900 dark:text-white">{result.totalWordsTyped}</span>
            <span className="text-xs text-slate-500 ml-1">/ {result.totalReferenceWords}</span>
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400">
            Ref. Words
          </div>
        </div>

        {/* Correct Words */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-bold uppercase">
            <span>Correct Words</span>
            <CheckCircle className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="my-1">
            <span className="text-2xl font-black text-emerald-600 dark:text-emerald-400">{result.correctWords}</span>
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400">
            Accurate matches
          </div>
        </div>

        {/* Incorrect / Errors */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between text-slate-500 dark:text-slate-400 text-xs font-bold uppercase">
            <span>Incorrect</span>
            <XCircle className="w-4 h-4 text-rose-500" />
          </div>
          <div className="my-1">
            <span className="text-2xl font-black text-rose-600 dark:text-rose-400">{result.incorrectWords}</span>
          </div>
          <div className="text-[11px] text-slate-500 dark:text-slate-400">
            +{result.missingWords} missing • +{result.extraWords} extra
          </div>
        </div>
      </div>

      {/* PERFORMANCE LEVEL BADGE BANNER */}
      <div className={`p-4 sm:p-5 rounded-2xl border ${gradeColors[result.performanceGrade]} flex flex-col sm:flex-row sm:items-center justify-between gap-3`}>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-white/80 dark:bg-slate-800 flex items-center justify-center font-black text-lg shadow-xs">
            {result.performanceGrade.charAt(0)}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase font-bold tracking-wider">Performance Rating:</span>
              <span className="text-base font-extrabold">{result.performanceGrade}</span>
            </div>
            <p className="text-xs sm:text-sm mt-0.5 opacity-90">
              {result.performanceDescription}
            </p>
          </div>
        </div>

        <div className="text-left sm:text-right shrink-0">
          <div className="text-xs font-bold">Passage Completion</div>
          <div className="text-base sm:text-lg font-black">{result.completionPercentage}% Completed</div>
        </div>
      </div>

      {/* DETAILED WORD & CHARACTER METRICS (Side-by-side) */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* A. WORD ANALYSIS */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-indigo-500" />
              A. Word Analysis (शब्द विश्लेषण)
            </h3>
            <span className="text-xs text-slate-400">{result.totalWordsTyped} typed</span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
              <span className="text-slate-500 dark:text-slate-400 block mb-1">Total Reference Words</span>
              <span className="text-base font-bold text-slate-900 dark:text-white">{result.totalReferenceWords}</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
              <span className="text-slate-500 dark:text-slate-400 block mb-1">Total Words Typed</span>
              <span className="text-base font-bold text-slate-900 dark:text-white">{result.totalWordsTyped}</span>
            </div>
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/50">
              <span className="text-emerald-700 dark:text-emerald-400 block mb-1">Correct Words</span>
              <span className="text-base font-bold text-emerald-700 dark:text-emerald-300">{result.correctWords}</span>
            </div>
            <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-800/50">
              <span className="text-rose-700 dark:text-rose-400 block mb-1">Incorrect Words</span>
              <span className="text-base font-bold text-rose-700 dark:text-rose-300">{result.incorrectWords}</span>
            </div>
            <div className="p-3 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50">
              <span className="text-amber-700 dark:text-amber-400 block mb-1">Missing Words (छूट गए)</span>
              <span className="text-base font-bold text-amber-700 dark:text-amber-300">{result.missingWords}</span>
            </div>
            <div className="p-3 rounded-xl bg-purple-50 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-800/50">
              <span className="text-purple-700 dark:text-purple-400 block mb-1">Extra Words (अतिरिक्त)</span>
              <span className="text-base font-bold text-purple-700 dark:text-purple-300">{result.extraWords}</span>
            </div>
          </div>
        </div>

        {/* B. CHARACTER & SPEED ANALYSIS */}
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-2">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-cyan-500" />
              B. Character &amp; Speed Analysis (वर्ण व गति)
            </h3>
            <span className="text-xs text-slate-400">{result.cpm} CPM</span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
              <span className="text-slate-500 dark:text-slate-400 block mb-1">Total Chars Typed</span>
              <span className="text-base font-bold text-slate-900 dark:text-white">{result.totalCharsTyped}</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
              <span className="text-slate-500 dark:text-slate-400 block mb-1">Correct Characters</span>
              <span className="text-base font-bold text-emerald-600 dark:text-emerald-400">{result.correctChars}</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
              <span className="text-slate-500 dark:text-slate-400 block mb-1">Gross Typing Speed</span>
              <span className="text-base font-bold text-slate-900 dark:text-white">{result.grossWPM} WPM</span>
            </div>
            <div className="p-3 rounded-xl bg-indigo-50 dark:bg-indigo-950/30 border border-indigo-200 dark:border-indigo-800/50">
              <span className="text-indigo-700 dark:text-indigo-400 block mb-1">Net Typing Speed</span>
              <span className="text-base font-bold text-indigo-700 dark:text-indigo-300">{result.netWPM} WPM</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
              <span className="text-slate-500 dark:text-slate-400 block mb-1">CPM (Keystrokes/Min)</span>
              <span className="text-base font-bold text-slate-900 dark:text-white">{result.cpm}</span>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60">
              <span className="text-slate-500 dark:text-slate-400 block mb-1">Accuracy / Error Rate</span>
              <span className="text-base font-bold text-slate-900 dark:text-white">{result.accuracyPercentage}% / {result.errorPercentage}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* E. PASSAGE COMPARISON & VISUAL DIFF */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              E. Passage Comparison &amp; Visual Diff (अनुच्छेद मिलान)
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              प्रत्येक शब्द का मिलान: हरा (सही), लाल (गलत), नारंगी (छूटा हुआ), बैंगनी (अतिरिक्त)
            </p>
          </div>
          <button
            onClick={() => setShowFullDiff(!showFullDiff)}
            className="flex items-center gap-1 text-xs font-bold text-indigo-600 dark:text-indigo-400"
          >
            {showFullDiff ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            <span>{showFullDiff ? 'छोटा करें' : 'विस्तार करें'}</span>
          </button>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap items-center gap-3 text-xs font-medium">
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300">
            <span className="w-2 h-2 rounded-full bg-emerald-500" /> Correct Word
          </span>
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300">
            <span className="w-2 h-2 rounded-full bg-rose-500" /> Incorrect / Typo
          </span>
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300">
            <span className="w-2 h-2 rounded-full bg-amber-500" /> Missing Word
          </span>
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded bg-purple-100 text-purple-800 dark:bg-purple-950/60 dark:text-purple-300">
            <span className="w-2 h-2 rounded-full bg-purple-500" /> Extra Word
          </span>
        </div>

        {/* Diff Flow Box */}
        {showFullDiff && (
          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 max-h-[320px] overflow-y-auto leading-relaxed text-sm">
            <div className="flex flex-wrap gap-1.5 font-normal">
              {result.diffTokens.map((token, idx) => {
                if (token.type === 'correct') {
                  return (
                    <span 
                      key={idx} 
                      className={`text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 px-1 py-0.5 rounded ${
                        result.language === 'hindi' ? 'font-hindi' : ''
                      }`}
                    >
                      {token.typed}
                    </span>
                  );
                } else if (token.type === 'incorrect') {
                  return (
                    <span 
                      key={idx} 
                      className={`inline-flex flex-col items-center bg-rose-50 dark:bg-rose-950/50 border border-rose-300 dark:border-rose-800 px-1.5 py-0.5 rounded text-xs ${
                        result.language === 'hindi' ? 'font-hindi' : ''
                      }`}
                      title={`Expected: ${token.expected}`}
                    >
                      <span className="line-through text-rose-600 dark:text-rose-400 font-bold">{token.typed}</span>
                      <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium">({token.expected})</span>
                    </span>
                  );
                } else if (token.type === 'missing') {
                  return (
                    <span 
                      key={idx} 
                      className={`text-amber-700 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 border border-dashed border-amber-400 px-1 py-0.5 rounded text-xs ${
                        result.language === 'hindi' ? 'font-hindi' : ''
                      }`}
                      title="Word omitted by candidate"
                    >
                      [{token.expected}]
                    </span>
                  );
                } else {
                  return (
                    <span 
                      key={idx} 
                      className={`text-purple-700 dark:text-purple-400 bg-purple-50 dark:bg-purple-950/40 border border-purple-300 px-1 py-0.5 rounded text-xs ${
                        result.language === 'hindi' ? 'font-hindi' : ''
                      }`}
                      title="Extra word"
                    >
                      +{token.typed}
                    </span>
                  );
                }
              })}
            </div>
          </div>
        )}
      </div>

      {/* D. ERROR REPORT TABLE */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-rose-500" />
              D. Detailed Error Report ({result.errors.length} Total Errors)
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              क्रमवार त्रुटि विवरण, अपेक्षित पाठ व आपकी प्रविष्टि
            </p>
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1 overflow-x-auto text-xs">
            {(['all', 'spelling', 'missing_word', 'extra_word', 'punctuation'] as const).map((f) => (
              <button
                key={f}
                onClick={() => setErrorFilter(f)}
                className={`px-2.5 py-1 rounded-lg capitalize whitespace-nowrap font-medium transition-colors ${
                  errorFilter === f
                    ? 'bg-rose-600 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                {f.replace('_', ' ')}
              </button>
            ))}
          </div>
        </div>

        {result.errors.length === 0 ? (
          <div className="p-6 rounded-xl bg-emerald-50 dark:bg-emerald-950/30 text-emerald-800 dark:text-emerald-300 text-center space-y-1">
            <CheckCircle className="w-8 h-8 text-emerald-500 mx-auto" />
            <h4 className="text-base font-bold">शून्य त्रुटि (Flawless Typing!)</h4>
            <p className="text-xs">आपने बिना किसी गलती के पूरा अनुच्छेद शुद्धता से टाइप किया है।</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-slate-700 dark:text-slate-300">
                  <th className="py-2.5 px-3 font-bold w-12">No.</th>
                  <th className="py-2.5 px-3 font-bold">Expected Text (अपेक्षित)</th>
                  <th className="py-2.5 px-3 font-bold">Your Typed Text (आपका टाइप)</th>
                  <th className="py-2.5 px-3 font-bold">Error Classification</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {filteredErrors.map((err) => (
                  <tr key={err.index} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-2.5 px-3 font-mono text-slate-400">{err.index}</td>
                    <td className={`py-2.5 px-3 font-semibold text-emerald-700 dark:text-emerald-400 ${
                      result.language === 'hindi' ? 'font-hindi text-sm' : ''
                    }`}>
                      {err.expected}
                    </td>
                    <td className={`py-2.5 px-3 font-semibold text-rose-600 dark:text-rose-400 line-through ${
                      result.language === 'hindi' ? 'font-hindi text-sm' : ''
                    }`}>
                      {err.typed}
                    </td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-900/40">
                        {err.description}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* G. RESULT ACTIONS (Bottom navigation buttons) */}
      <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-wrap items-center justify-between gap-3 no-print">
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onTryAgain}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition-all"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Practice Same Passage Again</span>
          </button>
          <button
            onClick={onChooseNewPassage}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold transition-all"
          >
            <BookOpen className="w-4 h-4" />
            <span>Choose New Passage</span>
          </button>
          <button
            onClick={onViewHistory}
            className="flex items-center gap-1.5 px-4 py-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-xl text-xs font-bold transition-all"
          >
            <History className="w-4 h-4" />
            <span>View My History</span>
          </button>
        </div>

        <button
          onClick={onBackToDashboard}
          className="flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Dashboard</span>
        </button>
      </div>

      {/* Scoring Formulas Modal */}
      {showFormulaModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-lg w-full p-6 border border-slate-200 dark:border-slate-800">
            <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2">
              <Info className="w-4 h-4 text-indigo-500" />
              Scoring Formulas &amp; Evaluation Standard
            </h3>
            <div className="space-y-3 text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl">
                <strong className="text-slate-900 dark:text-white block mb-0.5">1. Gross WPM (सकल गति):</strong>
                <code>Gross WPM = (Total Typed Characters / 5) / Time (Minutes)</code>
                <p className="text-[11px] text-slate-500 mt-1">अंतरराष्ट्रीय मानक व कर्मचारी चयन आयोग (SSC) के अनुसार 5 की-स्ट्रोक = 1 शब्द।</p>
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl">
                <strong className="text-slate-900 dark:text-white block mb-0.5">2. Net WPM (शुद्ध गति):</strong>
                <code>Net WPM = Gross WPM - (Total Errors / Time in Minutes)</code>
                <p className="text-[11px] text-slate-500 mt-1">जहाँ कुल त्रुटियाँ = गलत शब्द + छूटे हुए शब्द + अतिरिक्त शब्द।</p>
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl">
                <strong className="text-slate-900 dark:text-white block mb-0.5">3. Accuracy (शुद्धता प्रतिशत):</strong>
                <code>Accuracy % = (Correct Words / Total Words Processed) × 100</code>
              </div>

              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-xl">
                <strong className="text-slate-900 dark:text-white block mb-0.5">4. CPM (Characters Per Minute):</strong>
                <code>CPM = Total Characters / Time in Minutes</code>
              </div>
            </div>

            <div className="mt-5 pt-3 border-t border-slate-200 dark:border-slate-800 flex justify-end">
              <button
                onClick={() => setShowFormulaModal(false)}
                className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold"
              >
                Close (समझ गया)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
