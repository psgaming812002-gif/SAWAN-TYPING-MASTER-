import React, { useState } from 'react';
import { X, Moon, Sun, Volume2, VolumeX, Download, Trash2, CheckCircle2, User, Globe, Type, Sliders } from 'lucide-react';
import { AppSettings, UserProfile } from '../types';
import { exportDataAsJson, resetApplicationData, saveAppSettings, saveUserProfile } from '../utils/storage';
import { soundManager } from '../utils/sound';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  user: UserProfile | null;
  onUpdateSettings: (newSettings: AppSettings) => void;
  onUpdateUser: (newUser: UserProfile) => void;
  onResetAll: () => void;
}

export const SettingsModal: React.FC<Props> = ({
  isOpen,
  onClose,
  settings,
  user,
  onUpdateSettings,
  onUpdateUser,
  onResetAll,
}) => {
  const [name, setName] = useState(user?.name || '');
  const [currentSettings, setCurrentSettings] = useState<AppSettings>(settings);
  const [showSavedNotice, setShowSavedNotice] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);

  if (!isOpen) return null;

  const handleSave = () => {
    if (name.trim() && user) {
      const updatedUser: UserProfile = { ...user, name: name.trim() };
      saveUserProfile(updatedUser);
      onUpdateUser(updatedUser);
    }
    saveAppSettings(currentSettings);
    onUpdateSettings(currentSettings);
    soundManager.setEnabled(currentSettings.soundEnabled);

    setShowSavedNotice(true);
    setTimeout(() => {
      setShowSavedNotice(false);
      onClose();
    }, 800);
  };

  const handleExport = () => {
    const jsonStr = exportDataAsJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Smart_Typing_Backup_${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleReset = () => {
    resetApplicationData();
    onResetAll();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-2xl max-w-xl w-full max-h-[90vh] flex flex-col border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                Application Settings
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                प्राथमिकताएँ और छात्र प्रोफ़ाइल विन्यास
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Settings Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {/* Student Profile */}
          <div className="space-y-3">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <User className="w-3.5 h-3.5" /> Student Profile
            </label>
            <div>
              <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">
                Candidate / Student Name
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Enter your name"
                className="w-full px-3.5 py-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl text-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none dark:text-white"
              />
            </div>
          </div>

          {/* Language & Mode */}
          <div className="space-y-3 pt-2 border-t border-slate-200 dark:border-slate-800">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5" /> Language &amp; Mode
            </label>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Default Language
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setCurrentSettings({ ...currentSettings, defaultLanguage: 'hindi' })}
                    className={`py-2 px-3 text-xs font-bold rounded-lg border transition-all text-center ${
                      currentSettings.defaultLanguage === 'hindi'
                        ? 'bg-orange-500 text-white border-orange-500 shadow-sm'
                        : 'bg-slate-50 dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    हिंदी (Hindi)
                  </button>
                  <button
                    type="button"
                    onClick={() => setCurrentSettings({ ...currentSettings, defaultLanguage: 'english' })}
                    className={`py-2 px-3 text-xs font-bold rounded-lg border transition-all text-center ${
                      currentSettings.defaultLanguage === 'english'
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-sm'
                        : 'bg-slate-50 dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100'
                    }`}
                  >
                    English
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Default View
                </label>
                <select
                  value={currentSettings.defaultMode}
                  onChange={(e) => setCurrentSettings({ ...currentSettings, defaultMode: e.target.value as AppSettings['defaultMode'] })}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg text-xs font-medium text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                >
                  <option value="page_typing">Page Se Dekhkar Typing</option>
                  <option value="typing_test">Standard Typing Test (Exam)</option>
                  <option value="text_practice">Text Practice (Free Typing)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Typography & Appearance */}
          <div className="space-y-3 pt-2 border-t border-slate-200 dark:border-slate-800">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
              <Type className="w-3.5 h-3.5" /> Appearance &amp; Font Size
            </label>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Typing Text Size
                </label>
                <div className="grid grid-cols-4 gap-1">
                  {(['sm', 'md', 'lg', 'xl'] as const).map((size) => (
                    <button
                      key={size}
                      type="button"
                      onClick={() => setCurrentSettings({ ...currentSettings, fontSize: size })}
                      className={`py-1.5 text-xs font-semibold rounded border transition-all ${
                        currentSettings.fontSize === size
                          ? 'bg-indigo-600 text-white border-indigo-600'
                          : 'bg-slate-50 dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {size.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1.5">
                  Color Theme
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      setCurrentSettings({ ...currentSettings, theme: 'light' });
                      document.documentElement.classList.remove('dark');
                    }}
                    className={`flex items-center justify-center gap-1.5 py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                      currentSettings.theme === 'light'
                        ? 'bg-amber-500 text-white border-amber-500'
                        : 'bg-slate-50 dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <Sun className="w-3.5 h-3.5" /> Light
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setCurrentSettings({ ...currentSettings, theme: 'dark' });
                      document.documentElement.classList.add('dark');
                    }}
                    className={`flex items-center justify-center gap-1.5 py-1.5 text-xs font-semibold rounded-lg border transition-all ${
                      currentSettings.theme === 'dark'
                        ? 'bg-slate-800 text-white border-slate-600'
                        : 'bg-slate-50 dark:bg-slate-800 border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <Moon className="w-3.5 h-3.5" /> Dark
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Sound & Evaluation Settings */}
          <div className="space-y-3 pt-2 border-t border-slate-200 dark:border-slate-800">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Evaluation &amp; Audio Feedback
            </label>
            <div className="space-y-3">
              <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 cursor-pointer">
                <div className="flex items-center gap-2.5">
                  {currentSettings.soundEnabled ? (
                    <Volume2 className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                  ) : (
                    <VolumeX className="w-4 h-4 text-slate-400" />
                  )}
                  <div>
                    <span className="text-xs font-semibold text-slate-900 dark:text-white block">
                      Mechanical Typewriter Keystroke Sound
                    </span>
                    <span className="text-[11px] text-slate-500 dark:text-slate-400">
                      Subtle tactile audio feedback synthesized via Web Audio
                    </span>
                  </div>
                </div>
                <input
                  type="checkbox"
                  checked={currentSettings.soundEnabled}
                  onChange={(e) => {
                    const enabled = e.target.checked;
                    setCurrentSettings({ ...currentSettings, soundEnabled: enabled });
                    soundManager.setEnabled(enabled);
                    if (enabled) soundManager.playKeyClick();
                  }}
                  className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 cursor-pointer">
                <div>
                  <span className="text-xs font-semibold text-slate-900 dark:text-white block">
                    Strict Whitespace Evaluation
                  </span>
                  <span className="text-[11px] text-slate-500 dark:text-slate-400">
                    If checked, multiple spaces and newlines are counted as strict typing errors
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={currentSettings.strictWhitespace}
                  onChange={(e) => setCurrentSettings({ ...currentSettings, strictWhitespace: e.target.checked })}
                  className="rounded text-indigo-600 focus:ring-indigo-500 w-4 h-4 cursor-pointer"
                />
              </label>
            </div>
          </div>

          {/* Backup & Data Management */}
          <div className="space-y-3 pt-2 border-t border-slate-200 dark:border-slate-800">
            <label className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Data Management &amp; Backup
            </label>
            <div className="flex flex-col sm:flex-row gap-2.5">
              <button
                type="button"
                onClick={handleExport}
                className="flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 text-xs font-semibold transition-colors"
              >
                <Download className="w-3.5 h-3.5 text-indigo-600" /> Export History &amp; Backup
              </button>

              {!confirmReset ? (
                <button
                  type="button"
                  onClick={() => setConfirmReset(true)}
                  className="flex items-center justify-center gap-2 py-2 px-3 rounded-xl border border-rose-200 dark:border-rose-900/50 bg-rose-50 dark:bg-rose-950/30 text-rose-600 dark:text-rose-400 hover:bg-rose-100 text-xs font-semibold transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Reset All Data
                </button>
              ) : (
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleReset}
                    className="py-2 px-3 rounded-xl bg-rose-600 text-white text-xs font-bold hover:bg-rose-700 transition-colors"
                  >
                    Confirm Clear All
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmReset(false)}
                    className="py-2 px-3 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-medium"
                  >
                    Cancel
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-slate-50 dark:bg-slate-800/50 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <div>
            {showSavedNotice && (
              <span className="flex items-center gap-1.5 text-xs font-semibold text-emerald-600 dark:text-emerald-400">
                <CheckCircle2 className="w-4 h-4" /> Settings updated successfully!
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleSave}
              className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-sm transition-all"
            >
              Save Changes
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
