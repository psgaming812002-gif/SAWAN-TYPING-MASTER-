import React, { useState, useEffect, useRef } from 'react';
import { 
  ArrowLeft, 
  RotateCcw, 
  Trash2, 
  Clock, 
  CheckCircle2, 
  PenTool, 
  AlertCircle, 
  Languages, 
  HelpCircle,
  Play,
  Pause
} from 'lucide-react';
import { AppSettings, EvaluationResult, Language } from '../types';
import { evaluateFreeTyping, tokenizeWords } from '../utils/evaluation';
import { soundManager } from '../utils/sound';

interface Props {
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
  studentName: string;
  settings: AppSettings;
  onBack: () => void;
  onSubmitResult: (result: EvaluationResult) => void;
  onOpenHindiGuide: () => void;
}

export const TextPractice: React.FC<Props> = ({
  currentLanguage,
  onLanguageChange,
  studentName,
  settings,
  onBack,
  onSubmitResult,
  onOpenHindiGuide,
}) => {
  const [typedText, setTypedText] = useState('');
  const [selectedDurationMins, setSelectedDurationMins] = useState<number | 'unlimited'>(3);
  const [isTypingStarted, setIsTypingStarted] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [showEmptyNotice, setShowEmptyNotice] = useState(false);

  const startTimeRef = useRef<number | null>(null);
  const accumulatedMsRef = useRef<number>(0);
  const timerIntervalRef = useRef<number | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Clean timer on unmount
  useEffect(() => {
    return () => {
      if (timerIntervalRef.current) window.clearInterval(timerIntervalRef.current);
    };
  }, []);

  const startTimer = () => {
    if (timerIntervalRef.current) window.clearInterval(timerIntervalRef.current);
    startTimeRef.current = Date.now();

    timerIntervalRef.current = window.setInterval(() => {
      if (startTimeRef.current) {
        const now = Date.now();
        const totalMs = accumulatedMsRef.current + (now - startTimeRef.current);
        const totalSecs = Math.floor(totalMs / 1000);
        setElapsedSeconds(totalSecs);

        // Check if fixed duration reached
        if (typeof selectedDurationMins === 'number' && totalSecs >= selectedDurationMins * 60) {
          handleAutoFinish(totalSecs);
        }
      }
    }, 200);
  };

  const handleAutoFinish = (finalSecs: number) => {
    if (timerIntervalRef.current) {
      window.clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }
    const result = evaluateFreeTyping({
      typedText,
      durationSeconds: Math.max(finalSecs, 1),
      language: currentLanguage,
      studentName: studentName || 'Student',
    });
    soundManager.playSuccessChime();
    onSubmitResult(result);
  };

  const pauseTimer = () => {
    if (timerIntervalRef.current) {
      window.clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }
    if (startTimeRef.current) {
      accumulatedMsRef.current += Date.now() - startTimeRef.current;
      startTimeRef.current = null;
    }
    setIsPaused(true);
  };

  const resumeTimer = () => {
    setIsPaused(false);
    startTimer();
    if (textareaRef.current) textareaRef.current.focus();
  };

  const resetAll = () => {
    if (timerIntervalRef.current) {
      window.clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }
    startTimeRef.current = null;
    accumulatedMsRef.current = 0;
    setElapsedSeconds(0);
    setIsTypingStarted(false);
    setIsPaused(false);
    setTypedText('');
    setShowClearConfirm(false);
    setShowEmptyNotice(false);
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    if (!isTypingStarted && val.length > 0) {
      setIsTypingStarted(true);
      startTimer();
    }
    setTypedText(val);
    soundManager.playKeyClick();
  };

  // Live honest calculations
  const totalCharsTyped = typedText.length;
  const words = tokenizeWords(typedText);
  const totalWordsTyped = words.length;
  const minutes = Math.max(elapsedSeconds / 60, 0.05);

  const liveGrossWPM = isTypingStarted && elapsedSeconds > 0
    ? Math.round((totalCharsTyped / 5) / minutes)
    : 0;

  const liveCPM = isTypingStarted && elapsedSeconds > 0
    ? Math.round(totalCharsTyped / minutes)
    : 0;

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleSubmit = () => {
    if (!typedText.trim()) {
      setShowEmptyNotice(true);
      return;
    }

    if (timerIntervalRef.current) window.clearInterval(timerIntervalRef.current);
    const result = evaluateFreeTyping({
      typedText,
      durationSeconds: Math.max(elapsedSeconds, 1),
      language: currentLanguage,
      studentName: studentName || 'Student',
    });
    soundManager.playSuccessChime();
    onSubmitResult(result);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-4">
      {/* Top Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-extrabold text-slate-900 dark:text-white">
                TEXT PRACTICE (मुक्त टंकण अभ्यास)
              </h2>
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                currentLanguage === 'hindi'
                  ? 'bg-orange-100 text-orange-700 dark:bg-orange-950 dark:text-orange-400'
                  : 'bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-400'
              }`}>
                {currentLanguage === 'hindi' ? 'हिंदी' : 'English'}
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              बिना किसी संदर्भ गद्यांश के स्वतंत्र रूप से टाइप करें • लाइव गति व समय मापन
            </p>
          </div>
        </div>

        {/* Center Timer */}
        <div className="flex items-center gap-3 bg-slate-50 dark:bg-slate-800 px-4 py-2 rounded-2xl border border-slate-200 dark:border-slate-700">
          <div className="flex flex-col items-center">
            <span className="text-[10px] uppercase font-bold text-slate-400">
              {isTypingStarted ? (isPaused ? 'PAUSED' : 'ELAPSED') : 'TIMER'}
            </span>
            <span className="font-mono text-2xl font-black text-slate-900 dark:text-white">
              {formatTime(elapsedSeconds)}
            </span>
          </div>

          {isTypingStarted && (
            <button
              onClick={isPaused ? resumeTimer : pauseTimer}
              className={`p-2 rounded-xl text-xs font-bold ${
                isPaused ? 'bg-emerald-600 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200'
              }`}
            >
              {isPaused ? <Play className="w-4 h-4 fill-current" /> : <Pause className="w-4 h-4" />}
            </button>
          )}

          <button
            onClick={() => {
              if (typedText.trim()) setShowClearConfirm(true);
              else resetAll();
            }}
            className="p-2 rounded-xl bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300 hover:text-slate-900"
            title="Clear and Restart"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Language & Hindi Guide */}
        <div className="flex items-center gap-2">
          {currentLanguage === 'hindi' && (
            <button
              onClick={onOpenHindiGuide}
              className="px-2.5 py-1.5 bg-orange-50 dark:bg-orange-950/40 text-orange-600 dark:text-orange-400 border border-orange-200 dark:border-orange-800 rounded-xl text-xs font-semibold flex items-center gap-1"
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Hindi Guide</span>
            </button>
          )}

          <button
            onClick={() => onLanguageChange(currentLanguage === 'hindi' ? 'english' : 'hindi')}
            className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800"
          >
            {currentLanguage === 'hindi' ? 'Switch to English' : 'हिंदी मोड'}
          </button>
        </div>
      </div>

      {/* Duration Selector Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-3 shadow-xs flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <span className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-indigo-500" /> Practice Duration:
          </span>
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
            {([1, 3, 5, 10, 15, 'unlimited'] as const).map((dur) => (
              <button
                key={String(dur)}
                onClick={() => {
                  setSelectedDurationMins(dur);
                  resetAll();
                }}
                className={`px-3 py-1 rounded-lg font-medium transition-colors ${
                  selectedDurationMins === dur
                    ? 'bg-indigo-600 text-white shadow-xs font-bold'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                {dur === 'unlimited' ? 'Open (खुला)' : `${dur} Min`}
              </button>
            ))}
          </div>
        </div>

        {/* Clear Button */}
        <button
          onClick={() => {
            if (typedText.trim()) setShowClearConfirm(true);
            else resetAll();
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-rose-200 dark:border-rose-900 font-semibold"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Clear Text (साफ़ करें)</span>
        </button>
      </div>

      {/* Clear Confirmation Dialog */}
      {showClearConfirm && (
        <div className="p-4 bg-rose-50 dark:bg-rose-950/40 border border-rose-300 dark:border-rose-800 rounded-2xl flex items-center justify-between gap-4 animate-in fade-in">
          <div className="flex items-center gap-2 text-xs sm:text-sm text-rose-900 dark:text-rose-200">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
            <span>
              <strong>टेक्स्ट साफ़ करें (Clear Text)?</strong> आपका लिखा हुआ पूरा मैटर हट जाएगा।
            </span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={resetAll}
              className="px-3.5 py-1.5 bg-rose-600 text-white rounded-xl text-xs font-bold hover:bg-rose-700"
            >
              हाँ, साफ़ करें
            </button>
            <button
              onClick={() => setShowClearConfirm(false)}
              className="px-3.5 py-1.5 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-semibold"
            >
              रद्द करें
            </button>
          </div>
        </div>
      )}

      {/* Empty Notice */}
      {showEmptyNotice && (
        <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 rounded-2xl flex items-center justify-between text-xs text-amber-800 dark:text-amber-200">
          <span>सबमिट करने से पहले कृपया कुछ टेक्स्ट टाइप करें।</span>
          <button onClick={() => setShowEmptyNotice(false)} className="underline font-bold">बंद करें</button>
        </div>
      )}

      {/* Large Free Typing Area */}
      <div className="bg-white dark:bg-slate-900 border-2 border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-6 shadow-xs relative">
        <textarea
          ref={textareaRef}
          value={typedText}
          onChange={handleTextChange}
          disabled={isPaused}
          placeholder={
            currentLanguage === 'hindi'
              ? 'यहाँ स्वतंत्र रूप से हिंदी टाइपिंग अभ्यास करें... पहला की-स्ट्रोक दबाते ही टाइमर शुरू होगा।'
              : 'Type freely here in English... Timer starts automatically on your first keystroke.'
          }
          spellCheck={false}
          autoCapitalize="off"
          autoCorrect="off"
          autoComplete="off"
          rows={14}
          className={`w-full p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all resize-none text-base sm:text-lg leading-relaxed ${
            currentLanguage === 'hindi' ? 'font-hindi' : ''
          }`}
        />
      </div>

      {/* Honest Live Stats Ribbon */}
      <div className="bg-slate-900 text-white rounded-2xl p-4 shadow-lg grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
        <div>
          <span className="text-[10px] uppercase font-bold text-slate-400 block">Total Words Typed</span>
          <span className="font-mono text-2xl font-black text-white">{totalWordsTyped}</span>
        </div>
        <div>
          <span className="text-[10px] uppercase font-bold text-slate-400 block">Characters</span>
          <span className="font-mono text-2xl font-black text-cyan-400">{totalCharsTyped}</span>
        </div>
        <div>
          <span className="text-[10px] uppercase font-bold text-slate-400 block">Gross Speed</span>
          <span className="font-mono text-2xl font-black text-indigo-400">
            {liveGrossWPM} <span className="text-xs font-bold text-slate-400">WPM</span>
          </span>
        </div>
        <div>
          <span className="text-[10px] uppercase font-bold text-slate-400 block">Keystrokes / Min</span>
          <span className="font-mono text-2xl font-black text-emerald-400">
            {liveCPM} <span className="text-xs font-bold text-slate-400">CPM</span>
          </span>
        </div>
      </div>

      {/* Submit Button */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
        <span className="text-xs text-slate-500 dark:text-slate-400">
          * मुक्त टंकण में संदर्भ गद्यांश न होने के कारण केवल वास्तविक मापन (गति व शब्द संख्या) सहेजे जाते हैं।
        </span>
        <button
          onClick={handleSubmit}
          className="w-full sm:w-auto px-8 py-3.5 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-500 hover:to-blue-500 text-white font-bold text-sm rounded-xl shadow-lg shadow-indigo-600/25 flex items-center justify-center gap-2"
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>Save &amp; Submit Free Practice Session</span>
        </button>
      </div>
    </div>
  );
};
