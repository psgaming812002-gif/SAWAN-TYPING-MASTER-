import React, { useState, useEffect, useRef } from 'react';
import { 
  ArrowLeft, 
  RotateCcw, 
  Clock, 
  CheckCircle2, 
  ShieldCheck, 
  BookOpen, 
  Languages, 
  AlertTriangle,
  Play,
  FileCheck
} from 'lucide-react';
import { AppSettings, DifficultyLevel, EvaluationResult, Language, Passage } from '../types';
import { BUILT_IN_PASSAGES, getAllPassages } from '../data/passages';
import { evaluateTyping, tokenizeWords } from '../utils/evaluation';
import { soundManager } from '../utils/sound';

interface Props {
  currentLanguage: Language;
  onLanguageChange: (lang: Language) => void;
  studentName: string;
  settings: AppSettings;
  onBack: () => void;
  onSubmitResult: (result: EvaluationResult) => void;
  onOpenHindiGuide: () => void;
}

export const TypingTest: React.FC<Props> = ({
  currentLanguage,
  onLanguageChange,
  studentName,
  settings,
  onBack,
  onSubmitResult,
  onOpenHindiGuide,
}) => {
  // Test configuration state
  const [level, setLevel] = useState<DifficultyLevel | 'all'>('exam');
  const [testDurationMins, setTestDurationMins] = useState<number>(5);
  const [passages] = useState<Passage[]>(() => getAllPassages());
  const [selectedPassage, setSelectedPassage] = useState<Passage>(() => {
    const examList = getAllPassages().filter(p => p.language === currentLanguage && p.level === 'exam');
    return examList[0] || BUILT_IN_PASSAGES[0];
  });

  // Test execution state
  const [typedText, setTypedText] = useState('');
  const [isTestStarted, setIsTestStarted] = useState(false);
  const [timeRemainingSecs, setTimeRemainingSecs] = useState<number>(5 * 60);
  const [showAutoSubmitModal, setShowAutoSubmitModal] = useState(false);

  const startTimestampRef = useRef<number | null>(null);
  const totalAllocatedSecsRef = useRef<number>(5 * 60);
  const timerIntervalRef = useRef<number | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Sync passage when language or level changes
  useEffect(() => {
    const matching = passages.filter(p => p.language === currentLanguage && (level === 'all' || p.level === level));
    if (matching.length > 0) {
      setSelectedPassage(matching[0]);
    } else {
      const fallback = passages.filter(p => p.language === currentLanguage);
      if (fallback.length > 0) setSelectedPassage(fallback[0]);
    }
    resetTest(testDurationMins);
  }, [currentLanguage, level]);

  // Clean timer on unmount
  useEffect(() => {
    return () => {
      if (timerIntervalRef.current) window.clearInterval(timerIntervalRef.current);
    };
  }, []);

  const resetTest = (mins: number) => {
    if (timerIntervalRef.current) {
      window.clearInterval(timerIntervalRef.current);
      timerIntervalRef.current = null;
    }
    startTimestampRef.current = null;
    totalAllocatedSecsRef.current = mins * 60;
    setTimeRemainingSecs(mins * 60);
    setIsTestStarted(false);
    setTypedText('');
    setShowAutoSubmitModal(false);
  };

  const handleDurationSelect = (mins: number) => {
    setTestDurationMins(mins);
    resetTest(mins);
  };

  // Start countdown on first keystroke
  const startCountdown = () => {
    if (timerIntervalRef.current) window.clearInterval(timerIntervalRef.current);
    startTimestampRef.current = Date.now();
    const totalSecs = totalAllocatedSecsRef.current;

    timerIntervalRef.current = window.setInterval(() => {
      if (startTimestampRef.current) {
        const elapsedSecs = Math.floor((Date.now() - startTimestampRef.current) / 1000);
        const rem = Math.max(0, totalSecs - elapsedSecs);
        setTimeRemainingSecs(rem);

        if (rem <= 0) {
          if (timerIntervalRef.current) window.clearInterval(timerIntervalRef.current);
          handleAutoSubmit();
        }
      }
    }, 250);
  };

  const handleAutoSubmit = () => {
    setShowAutoSubmitModal(true);
    setTimeout(() => {
      performFinalSubmission(totalAllocatedSecsRef.current);
    }, 1200);
  };

  const performFinalSubmission = (actualDurationSecs: number) => {
    if (timerIntervalRef.current) window.clearInterval(timerIntervalRef.current);

    const evaluation = evaluateTyping({
      referenceText: selectedPassage.content,
      typedText: typedText,
      durationSeconds: Math.max(actualDurationSecs, 1),
      language: selectedPassage.language,
      mode: 'typing_test',
      passageId: selectedPassage.id,
      passageTitle: selectedPassage.title,
      studentName: studentName || 'Candidate',
      strictWhitespace: settings.strictWhitespace,
    });

    soundManager.playSuccessChime();
    onSubmitResult(evaluation);
  };

  const handleManualSubmit = () => {
    if (!typedText.trim()) return;
    const elapsed = totalAllocatedSecsRef.current - timeRemainingSecs;
    performFinalSubmission(Math.max(elapsed, 1));
  };

  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const val = e.target.value;
    if (!isTestStarted && val.length > 0) {
      setIsTestStarted(true);
      startCountdown();
    }
    setTypedText(val);
    soundManager.playKeyClick();
  };

  const formatCountdown = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  // Matching passages for dropdown
  const availablePassages = passages.filter(p => p.language === currentLanguage);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-4">
      {/* Top Exam Header */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
              <h2 className="text-base font-extrabold text-slate-900 dark:text-white">
                STANDARD TYPING TEST (सरकारी एवं क्लर्क परीक्षा प्रारूप)
              </h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              समय सीमा समाप्त होते ही टेस्ट स्वतः सबमिट हो जाएगा • हूबहू टाइपिंग अनिवार्य है
            </p>
          </div>
        </div>

        {/* Countdown Timer Display */}
        <div className={`flex items-center gap-2.5 px-5 py-2.5 rounded-2xl border ${
          timeRemainingSecs <= 60 && isTestStarted
            ? 'bg-rose-50 dark:bg-rose-950/50 border-rose-400 text-rose-600 animate-pulse'
            : 'bg-slate-50 dark:bg-slate-800 border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white'
        }`}>
          <Clock className="w-5 h-5 text-indigo-500" />
          <div className="flex flex-col items-center">
            <span className="text-[10px] uppercase font-bold tracking-wider opacity-70">
              {isTestStarted ? 'TIME LEFT (उल्टी गिनती)' : 'SET DURATION'}
            </span>
            <span className="font-mono text-2xl font-black">
              {formatCountdown(timeRemainingSecs)}
            </span>
          </div>
        </div>

        {/* Action button */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => resetTest(testDurationMins)}
            className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:text-slate-900"
            title="Reset Exam Test"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Exam Configuration Pills */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-xs grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
        {/* Exam Level */}
        <div>
          <span className="font-bold text-slate-700 dark:text-slate-300 block mb-1.5">
            1. Examination Level:
          </span>
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
            {(['beginner', 'intermediate', 'advanced', 'exam'] as const).map((lvl) => (
              <button
                key={lvl}
                onClick={() => setLevel(lvl)}
                className={`flex-1 py-1 px-1 rounded-lg capitalize text-center font-semibold transition-all ${
                  level === lvl
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                {lvl === 'exam' ? 'Govt Exam' : lvl}
              </button>
            ))}
          </div>
        </div>

        {/* Test Duration */}
        <div>
          <span className="font-bold text-slate-700 dark:text-slate-300 block mb-1.5">
            2. Test Duration (Minutes):
          </span>
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl">
            {([1, 5, 10, 15, 30] as const).map((mins) => (
              <button
                key={mins}
                onClick={() => handleDurationSelect(mins)}
                className={`flex-1 py-1 rounded-lg text-center font-semibold transition-all ${
                  testDurationMins === mins
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                {mins}m
              </button>
            ))}
          </div>
        </div>

        {/* Passage Dropdown */}
        <div>
          <span className="font-bold text-slate-700 dark:text-slate-300 block mb-1.5">
            3. Exam Question Paper / Passage:
          </span>
          <select
            value={selectedPassage.id}
            onChange={(e) => {
              const p = passages.find(item => item.id === e.target.value);
              if (p) {
                setSelectedPassage(p);
                resetTest(testDurationMins);
              }
            }}
            className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-xl font-medium text-slate-800 dark:text-slate-200 focus:ring-2 focus:ring-indigo-500 focus:outline-none truncate"
          >
            {availablePassages.map((p) => (
              <option key={p.id} value={p.id}>
                {p.title} ({p.wordCount} words)
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Exam Split Screen */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Question Paper Reference Panel */}
        <div className="bg-amber-50/40 dark:bg-slate-900 border-2 border-amber-300/80 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between">
          <div className="border-b border-amber-200 dark:border-slate-800 pb-2 mb-3 flex items-center justify-between text-xs text-amber-900 dark:text-slate-400 font-bold">
            <span className="flex items-center gap-1.5 uppercase">
              <FileCheck className="w-4 h-4 text-amber-600" />
              QUESTION PAPER (गद्यांश पत्रक)
            </span>
            <span className="font-mono text-slate-500">{selectedPassage.wordCount} Words</span>
          </div>

          <div 
            tabIndex={0}
            aria-label="Exam reference passage"
            className={`max-h-[360px] overflow-y-auto pr-2 text-slate-800 dark:text-slate-200 text-base leading-loose select-text focus:outline-none focus:ring-1 focus:ring-amber-400/50 rounded-lg ${
              selectedPassage.language === 'hindi' ? 'font-hindi' : ''
            }`}
          >
            {selectedPassage.content}
          </div>

          <div className="mt-4 pt-2 border-t border-amber-200/60 dark:border-slate-800 text-[11px] text-amber-800/80 dark:text-slate-500">
            * परीक्षा निर्देश: पैराग्राफ, विराम चिह्न और मात्राओं का विशेष ध्यान रखें।
          </div>
        </div>

        {/* Candidate Typing Area */}
        <div className="bg-white dark:bg-slate-900 border-2 border-indigo-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs flex flex-col justify-between">
          <div className="border-b border-slate-200 dark:border-slate-800 pb-2 mb-3 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-bold">
            <span className="text-slate-900 dark:text-white">CANDIDATE ANSWER AREA</span>
            <span>{isTestStarted ? 'परीक्षा जारी है...' : 'प्रथम की-स्ट्रोक पर उल्टी गिनती शुरू होगी'}</span>
          </div>

          <textarea
            ref={textareaRef}
            value={typedText}
            onChange={handleTextChange}
            placeholder={
              selectedPassage.language === 'hindi'
                ? 'यहाँ देखकर टाइप करें... पहला की-स्ट्रोक दबाते ही परीक्षा की उल्टी गिनती चालू होगी।'
                : 'Begin typing the passage here... Countdown starts automatically on your first keystroke.'
            }
            spellCheck={false}
            autoCapitalize="off"
            autoCorrect="off"
            autoComplete="off"
            rows={12}
            className={`w-full p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all resize-none text-base leading-loose ${
              selectedPassage.language === 'hindi' ? 'font-hindi' : ''
            }`}
          />

          <div className="mt-3 flex items-center justify-between text-xs font-semibold text-slate-500 dark:text-slate-400">
            <span>Typed Words: {tokenizeWords(typedText).length}</span>
            <span>Total Characters: {typedText.length}</span>
          </div>
        </div>
      </div>

      {/* Manual Submit Button */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
        <span className="text-xs text-slate-500 dark:text-slate-400">
          * समय समाप्त होते ही स्वतः सबमिट होगा, अथवा आप पहले भी सबमिट कर सकते हैं।
        </span>
        <button
          onClick={handleManualSubmit}
          disabled={!typedText.trim()}
          className={`w-full sm:w-auto px-8 py-3.5 rounded-xl font-bold text-sm shadow-md flex items-center justify-center gap-2 transition-all ${
            typedText.trim()
              ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/20'
              : 'bg-slate-200 dark:bg-slate-800 text-slate-400 cursor-not-allowed'
          }`}
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>Final Submit Test</span>
        </button>
      </div>

      {/* Auto Submit Notification Dialog */}
      {showAutoSubmitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-in fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 text-center shadow-2xl max-w-sm w-full space-y-3">
            <Clock className="w-12 h-12 text-rose-500 mx-auto animate-bounce" />
            <h3 className="text-lg font-black text-slate-900 dark:text-white">
              समय समाप्त! (Time Over)
            </h3>
            <p className="text-xs text-slate-500">
              निर्धारित परीक्षा समय पूरा हो गया है। आपका टेस्ट सबमिट किया जा रहा है...
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
