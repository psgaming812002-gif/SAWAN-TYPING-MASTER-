import { Passage } from '../types';

export const BUILT_IN_PASSAGES: Passage[] = [
  // ================= ENGLISH PASSAGES =================
  {
    id: 'eng-beg-1',
    title: 'The Morning Walk',
    language: 'english',
    level: 'beginner',
    lengthCategory: 'short',
    wordCount: 48,
    charCount: 254,
    source: 'General Practice',
    content: 'A morning walk is a very good exercise. It refreshes our mind and makes our body healthy and strong. Fresh air in the morning gives us energy for the entire day. Birds chirp sweetly in the green trees, and the cool morning breeze brings happiness to all.'
  },
  {
    id: 'eng-beg-2',
    title: 'Importance of Trees',
    language: 'english',
    level: 'beginner',
    lengthCategory: 'medium',
    wordCount: 112,
    charCount: 632,
    source: 'School Reader',
    content: 'Trees are our best friends. They give us oxygen to breathe and clean the air around us. They provide shade during hot sunny days and give us sweet fruits to eat. Without trees, the earth would become a dry desert. Birds build their homes on the branches of tall green trees. In addition, trees prevent soil erosion and bring rainfall. We must protect our forests and plant more trees in our neighborhoods. Taking care of nature is our collective duty, and it makes our planet a wonderful place for future generations.'
  },
  {
    id: 'eng-int-1',
    title: 'Digital Literacy in Modern Era',
    language: 'english',
    level: 'intermediate',
    lengthCategory: 'medium',
    wordCount: 145,
    charCount: 928,
    source: 'Computer Education Board',
    content: 'In today’s fast-paced digital era, keyboard proficiency and computer literacy have become essential life skills. Whether you are drafting a professional email, writing an academic report, or entering data into office software, your typing speed directly impacts your productivity. Fast and accurate typists can translate their thoughts into digital text effortlessly without looking down at the keyboard. This cognitive flow state allows professionals to focus on creative thinking rather than physical mechanics. Furthermore, regular practice with proper finger positioning strengthens muscle memory, reduces ergonomic strain on the wrists, and builds lasting confidence for competitive examinations and administrative roles.'
  },
  {
    id: 'eng-int-2',
    title: 'The Power of Consistency',
    language: 'english',
    level: 'intermediate',
    lengthCategory: 'long',
    wordCount: 228,
    charCount: 1408,
    source: 'Self Improvement Series',
    content: 'Consistency is the silent architect of genuine excellence. When people observe extraordinary achievements in sports, academics, or music, they often attribute success to raw talent. However, history demonstrates that steady daily discipline invariably outperforms sporadic bursts of intense effort. Consider a student learning how to type with speed and accuracy. On the very first day, fingers may feel clumsy, keystrokes may hesitate, and typos may occur frequently. Yet, when that learner commits to twenty minutes of focused practice each morning, neural pathways steadily calibrate. The subconscious mind memorizes the exact spatial coordinate of every alphanumeric key. Over weeks and months, hesitant taps transform into an instinctive, rhythmic dance across the keyboard. This transformative principle applies across all human endeavors. Small positive actions, compounded consistently over sustained periods of time, yield monumental improvements. Therefore, do not be discouraged by initial stumbling blocks. Embrace every mistake as an informative checkpoint, maintain your focus, and trust the compounding power of persistent dedication.'
  },
  {
    id: 'eng-adv-1',
    title: 'Philosophy of Time and Technology',
    language: 'english',
    level: 'advanced',
    lengthCategory: 'long',
    wordCount: 265,
    charCount: 1782,
    source: 'Contemporary Essays',
    content: 'The relentless acceleration of computational technology has profoundly reshaped the human perception of temporality. In centuries past, communication was intrinsically tethered to geographic distance and physical conveyance. Letters traveled aboard horse-drawn carriages or sailing vessels, demanding weeks of patient anticipation before a reply could be received. Today, instantaneous algorithmic networks transmit vast repositories of data across continents in mere fractions of a second. While this hyper-connectivity undeniably accelerates commercial transactions and scientific collaboration, it simultaneously fosters a pervasive culture of chronic urgency. Modern professionals frequently find themselves inundated by relentless notifications, ephemeral messages, and multifaceted obligations that fragment cognitive focus. True intellectual depth, however, requires contemplative silence, sustained attention, and methodical deliberation. To master technology rather than succumb to its chaotic momentum, one must cultivate deliberate digital boundaries. We must appreciate computational efficiency not as an end in itself, but as an enabling instrument that frees human energy for higher creative, philosophical, and interpersonal pursuits.'
  },
  {
    id: 'eng-exam-1',
    title: 'SSC / Clerk Typing Exam Model - Passage A',
    language: 'english',
    level: 'exam',
    lengthCategory: 'medium',
    wordCount: 175,
    charCount: 1055,
    source: 'SSC CHSL / CGL Official Test Format',
    content: 'Good governance is the cornerstone of sustainable socio-economic development in any democratic nation. It encompasses transparency, accountability, equity, and the strict adherence to the rule of law. When public institutions operate efficiently and transparently, citizens experience enhanced access to essential public utilities, educational institutions, and healthcare infrastructure. Moreover, systematic simplification of administrative procedures curtails bureaucratic bottlenecks and minimizes corruption. Civil service examinations rigorously evaluate candidates’ clerical precision, attention to detail, and rapid data transcription abilities. An effective public servant must exhibit meticulous accuracy while handling government correspondence, legislative documentation, and citizen grievances. Speed without precision leads to administrative delays and legal disputes; therefore, maintaining high accuracy is paramount in all official secretarial operations. Candidates are advised to read each sentence carefully, adhere strictly to capitalization and punctuation guidelines, and ensure an even, disciplined typing cadence throughout the duration of the examination.'
  },
  {
    id: 'eng-exam-2',
    title: 'High Court & Judicial Typist Exam Test - Passage B',
    language: 'english',
    level: 'exam',
    lengthCategory: 'long',
    wordCount: 290,
    charCount: 1860,
    source: 'Judicial Secretariat Typing Examination',
    content: 'The judicial administration of justice necessitates absolute precision and fidelity in recording witness testimonies, legal pleadings, and court orders. Any typographical discrepancy or erroneous transcription can alter the substantive meaning of an adjudication, potentially prejudicing the constitutional rights of litigating parties. Modern court registries have undergone extensive digital modernization, replacing manual typewriter registers with comprehensive electronic filing systems. Under the e-Courts initiative, judicial stenographers and data entry operators are required to transcribe oral arguments and judicial decrees with exemplary speed and impeccable fidelity. In competitive judicial clerkship examinations, candidates are rigorously tested on their ability to transcribe complex legal terminology, statute references, paragraph numbering, and statutory citations without omissions or unwarranted additions. Speed benchmarks typically mandate an entry speed of at least thirty-five to forty words per minute, accompanied by an accuracy threshold of ninety-five percent or higher. To achieve this benchmark, practitioners must master touch typing principles, refrain from looking down at the keyboard, and maintain calm composure under timed examination pressure. Thorough familiarity with formal English syntax, standard capitalization protocols, and grammatical conventions is indispensable for securing high merit rank in official recruitment examinations.'
  },

  // ================= HINDI PASSAGES (DEVANAGARI UNICODE) =================
  {
    id: 'hin-beg-1',
    title: 'हमारा प्यारा भारत',
    language: 'hindi',
    level: 'beginner',
    lengthCategory: 'short',
    wordCount: 46,
    charCount: 250,
    source: 'प्राथमिक अभ्यास',
    content: 'भारत हमारा प्यारा देश है। यहाँ विभिन्न धर्मों और संस्कृतियों के लोग प्रेम और भाईचारे के साथ रहते हैं। हमारे देश में अनेक नदियाँ बहती हैं जैसे गंगा, यमुना और गोदावरी। हिमालय पर्वत उत्तर दिशा में भारत का मुकुट बनकर खड़ा है। हमें अपने देश पर गर्व है।'
  },
  {
    id: 'hin-beg-2',
    title: 'समय का महत्व',
    language: 'hindi',
    level: 'beginner',
    lengthCategory: 'medium',
    wordCount: 98,
    charCount: 520,
    source: 'सरल हिंदी पाठमाला',
    content: 'समय बहुत अनमोल धन है। बीता हुआ समय कभी वापस नहीं आता। जो व्यक्ति समय का सदुपयोग करता है, वह जीवन में सदैव सफलता प्राप्त करता है। आलस्य मनुष्य का सबसे बड़ा शत्रु है। हमें अपने सभी कार्य समय पर पूरे करने चाहिए। विद्यार्थी जीवन में समय का महत्व और भी अधिक बढ़ जाता है। नियमित अध्ययन और अभ्यास से कठिन से कठिन लक्ष्य भी आसानी से हासिल किए जा सकते हैं। समय की पाबंदी हमें अनुशासन और आत्मविश्वास सिखाती है। इसलिए प्रत्येक पल का सदुपयोग करें।'
  },
  {
    id: 'hin-int-1',
    title: 'कंप्यूटर और आधुनिक युग',
    language: 'hindi',
    level: 'intermediate',
    lengthCategory: 'medium',
    wordCount: 135,
    charCount: 790,
    source: 'तकनीकी ज्ञान मंच',
    content: 'आज का युग सूचना प्रौद्योगिकी और कंप्यूटर का युग है। जीवन के प्रत्येक क्षेत्र में कंप्यूटर और इंटरनेट का उपयोग तेजी से बढ़ रहा है। बैंक, रेलवे, हवाई अड्डे, शिक्षण संस्थान और सरकारी कार्यालयों में लगभग सभी कार्य डिजिटल रूप से संपन्न हो रहे हैं। हिंदी टाइपिंग का ज्ञान आज के समय में बहुत आवश्यक हो गया है। विभिन्न सरकारी विभागों और सार्वजनिक उपक्रमों में हिंदी टंकक और आशुलिपिक की बहुत मांग है। यदि कोई विद्यार्थी नियमित रूप से हिंदी टाइपिंग का अभ्यास करता है, तो वह आसानी से उच्च गति और अचूक शुद्धता प्राप्त कर सकता है। कीबोर्ड पर सही उंगलियों का अभ्यास करने से आत्मविश्वास बढ़ता है और गलतियों की संभावना कम हो जाती है।'
  },
  {
    id: 'hin-int-2',
    title: 'पर्यावरण संरक्षण और मानव दायित्व',
    language: 'hindi',
    level: 'intermediate',
    lengthCategory: 'long',
    wordCount: 215,
    charCount: 1250,
    source: 'पर्यावरण चेतना पत्रिका',
    content: 'प्रकृति और पर्यावरण का हमारे जीवन से गहरा संबंध है। स्वस्थ पर्यावरण के बिना मानव जीवन की कल्पना भी नहीं की जा सकती। लेकिन आधुनिक औद्योगीकरण और अनियंत्रित विकास की दौड़ में हमने प्रकृति को भारी नुकसान पहुंचाया है। जंगलों की अंधाधुंध कटाई से वन्यजीवों का आवास नष्ट हो रहा है और वैश्विक तापमान में निरंतर वृद्धि हो रही है। नदियों में औद्योगिक कचरा बहाने से हमारा जल प्रदूषित हो रहा है, जिससे अनेक प्रकार की बीमारियां जन्म ले रही हैं। यदि हमने समय रहते ठोस कदम नहीं उठाए, तो आने वाली पीढ़ियों को भयंकर संकट का सामना करना पड़ेगा। पर्यावरण की रक्षा करना केवल सरकार का काम नहीं है, बल्कि यह हम सभी नागरिकों का नैतिक कर्तव्य है। हमें अधिक से अधिक पेड़ लगाने चाहिए, पानी की बर्बादी रोकनी चाहिए और प्लास्टिक का उपयोग बंद करना चाहिए। सौर ऊर्जा और नवीकरणीय ऊर्जा स्रोतों को अपनाकर हम अपनी पृथ्वी को हरा-भरा और सुरक्षित बना सकते हैं। शुद्ध हवा और स्वच्छ जल ही हमारी सच्ची धरोहर हैं।'
  },
  {
    id: 'hin-adv-1',
    title: 'भारतीय संस्कृति एवं दर्शन',
    language: 'hindi',
    level: 'advanced',
    lengthCategory: 'long',
    wordCount: 245,
    charCount: 1485,
    source: 'साहित्यिक एवं दार्शनिक निबंध',
    content: 'भारतीय संस्कृति संसार की प्राचीनतम और समृद्धतम संस्कृतियों में से एक है। इसकी सबसे बड़ी विशेषता अनेकता में एकता और सर्वधर्म समभाव है। प्राचीन काल से ही हमारे ऋषियों और मुनियों ने ‘वसुधैव कुटुंबकम्’ का अमर संदेश दिया है, जिसका अर्थ है संपूर्ण पृथ्वी ही एक परिवार है। सत्य, अहिंसा, त्याग और करुणा हमारी सांस्कृतिक चेतना के मूल स्तंभ रहे हैं। उपनिषदों और वेदों से लेकर कबीर, तुलसी, सूरदास और गुरु नानक के वचनों तक मानवीय मूल्यों की ही प्रतिष्ठा की गई है। भौतिक समृद्धि के साथ-साथ आत्मिक शांति और चरित्र निर्माण को भारतीय चिंतन में सर्वोच्च प्राथमिकता दी गई है। वर्तमान युग में जहाँ स्वार्थ, तनाव और द्वेष बढ़ता जा रहा है, वहाँ भारतीय जीवन दृष्टि संपूर्ण विश्व को शांति और सद्भाव का सच्चा मार्ग दिखा सकती है। हमें अपनी सांस्कृतिक जड़ों से जुड़े रहकर आधुनिक वैज्ञानिक दृष्टिकोण को अपनाना चाहिए, ताकि राष्ट्र का सर्वांगीण विकास संभव हो सके।'
  },
  {
    id: 'hin-exam-1',
    title: 'कर्मचारी चयन आयोग (SSC) हिंदी टंकण परीक्षा मॉडल',
    language: 'hindi',
    level: 'exam',
    lengthCategory: 'medium',
    wordCount: 168,
    charCount: 980,
    source: 'SSC CHSL / CPT हिंदी टंकण नमूना पत्र',
    content: 'प्रशासनिक कार्यों में राजभाषा हिंदी का प्रयोग निरंतर बढ़ रहा है। भारत सरकार के सभी मंत्रालयों और अधीनस्थ कार्यालयों में हिंदी पत्राचार को प्राथमिकता दी जा रही है। किसी भी सरकारी कार्यालय में दक्षता और समयबद्धता अत्यंत महत्वपूर्ण मानी जाती है। टंकण परीक्षा में अभ्यर्थियों की गति और शुद्धता दोनों का समान रूप से मूल्यांकन किया जाता है। सामान्यतः हिंदी टंकण परीक्षा में तीस शब्द प्रति मिनट की गति और नब्बे से पंचानवे प्रतिशत शुद्धता अनिवार्य होती है। परीक्षा कक्ष में शांति और एकाग्रता बनाए रखना बहुत आवश्यक है। अभ्यर्थियों को सलाह दी जाती है कि वे स्क्रीन अथवा प्रश्नपत्र पर दिए गए गद्यांश को ध्यानपूर्वक देखकर टाइप करें। मात्राओं, संयुक्त अक्षरों और विराम चिह्नों का विशेष ध्यान रखना चाहिए। किसी भी शब्द को छोड़ना अथवा अतिरिक्त शब्द जोड़ना परीक्षा नियमों के अनुसार गंभीर त्रुटि माना जाता है। नियमित और अनुशासित अभ्यास ही परीक्षा में सफलता की असली कुंजी है।'
  },
  {
    id: 'hin-exam-2',
    title: 'उच्च न्यायालय / कनिष्ठ लिपिक भर्ती परीक्षा प्रश्नपत्र',
    language: 'hindi',
    level: 'exam',
    lengthCategory: 'long',
    wordCount: 260,
    charCount: 1530,
    source: 'न्यायालय लिपिक / आशुलिपिक परीक्षा प्रारूप',
    content: 'न्यायपालिका देश के प्रत्येक नागरिक के मौलिक अधिकारों की संरक्षक है। न्यायालय में प्रस्तुत होने वाले वादों, याचिकाओं और निर्णयों का दस्तावेजीकरण पूर्ण शुद्धता के साथ किया जाना अनिवार्य होता है। किसी भी न्यायिक अभिलेख में टाइपिंग की एक छोटी सी त्रुटि भी न्याय की दिशा को प्रभावित कर सकती है। इसलिए न्यायालयों में कनिष्ठ लिपिक और आशुलिपिक पदों के लिए आयोजित होने वाली टंकण परीक्षाओं का स्तर काफी कड़ा होता है। इन परीक्षाओं में कानूनी शब्दावली, अधिनियमों के संदर्भ, अनुच्छेदों की संख्या और विराम चिह्नों का सटीक प्रयोग परखा जाता है। परीक्षार्थी को दिए गए निश्चित समय में पूरे गद्यांश को बिना किसी छूट या गलती के टाइप करना होता है। बैकस्पेस का अत्यधिक प्रयोग आपकी गति को धीमा कर सकता है, इसलिए पहली बार में ही सही की दबाने की आदत डालें। स्क्रीन और कीबोर्ड के बीच सही सामंजस्य स्थापित करना ही कुशल टंकक की पहचान है। जो विद्यार्थी प्रतिदिन निर्धारित समय सीमा के भीतर विभिन्न प्रकार के विधिक और साहित्यिक अनुच्छेदों का अभ्यास करते हैं, वे परीक्षा में सर्वोच्च अंक प्राप्त करके अपना चयन सुनिश्चित करते हैं।'
  }
];

export const PASSAGE_STORAGE_KEY = 'smart_typing_custom_passages';

export function getAllPassages(): Passage[] {
  try {
    const customJson = localStorage.getItem(PASSAGE_STORAGE_KEY);
    if (customJson) {
      const customPassages: Passage[] = JSON.parse(customJson);
      return [...BUILT_IN_PASSAGES, ...customPassages];
    }
  } catch (err) {
    console.error('Failed to load custom passages', err);
  }
  return BUILT_IN_PASSAGES;
}

export function saveCustomPassage(passage: Omit<Passage, 'id' | 'isCustom'>): Passage {
  const newPassage: Passage = {
    ...passage,
    id: `custom-${Date.now()}`,
    isCustom: true
  };
  try {
    const existing = getAllPassages().filter(p => p.isCustom);
    existing.push(newPassage);
    localStorage.setItem(PASSAGE_STORAGE_KEY, JSON.stringify(existing));
  } catch (err) {
    console.error('Failed to save custom passage', err);
  }
  return newPassage;
}
