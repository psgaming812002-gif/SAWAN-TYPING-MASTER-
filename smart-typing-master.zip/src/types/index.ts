export type Language = 'hindi' | 'english';

export type PracticeMode = 'page_typing' | 'typing_test' | 'text_practice';

export type DifficultyLevel = 'beginner' | 'intermediate' | 'advanced' | 'exam';

export type PassageLength = 'short' | 'medium' | 'long';

export interface UserProfile {
  name: string;
  preferredLanguage: Language;
  createdAt: string;
  avatarSeed?: string;
}

export interface Passage {
  id: string;
  title: string;
  language: Language;
  level: DifficultyLevel;
  lengthCategory: PassageLength;
  content: string;
  wordCount: number;
  charCount: number;
  source?: string;
  isCustom?: boolean;
}

export type ErrorType = 
  | 'spelling' 
  | 'missing_word' 
  | 'extra_word' 
  | 'wrong_char' 
  | 'punctuation' 
  | 'case_error';

export interface DetailedError {
  index: number;
  expected: string;
  typed: string;
  type: ErrorType;
  description: string;
}

export interface DiffToken {
  type: 'correct' | 'incorrect' | 'missing' | 'extra';
  expected?: string;
  typed?: string;
  charDiffs?: {
    char: string;
    status: 'correct' | 'incorrect' | 'missing' | 'extra';
  }[];
}

export interface EvaluationResult {
  id: string;
  studentName: string;
  date: string;
  timestamp: number;
  language: Language;
  mode: PracticeMode;
  passageId?: string;
  passageTitle: string;
  durationSeconds: number;
  timeFormatted: string;
  
  // Word Metrics
  totalReferenceWords: number;
  totalWordsTyped: number;
  correctWords: number;
  incorrectWords: number;
  missingWords: number;
  extraWords: number;

  // Character Metrics
  totalReferenceChars: number;
  totalCharsTyped: number;
  correctChars: number;
  incorrectChars: number;
  missingChars: number;
  extraChars: number;

  // Speeds
  grossWPM: number;
  netWPM: number;
  cpm: number;
  hindiSpeedLabel?: string; // e.g. "32 शब्द/मिनट"

  // Rates
  accuracyPercentage: number;
  errorPercentage: number;
  completionPercentage: number;

  // Performance Rating
  performanceGrade: 'Beginner' | 'Improving' | 'Good' | 'Very Good' | 'Excellent';
  performanceDescription: string;

  // Detailed Analysis
  errors: DetailedError[];
  diffTokens: DiffToken[];
  originalTypedText: string;
  referenceText: string;

  // Free typing flag
  isFreeTyping?: boolean;
}

export interface AppSettings {
  studentName: string;
  defaultLanguage: Language;
  defaultMode: PracticeMode;
  fontSize: 'sm' | 'md' | 'lg' | 'xl';
  theme: 'light' | 'dark';
  soundEnabled: boolean;
  strictWhitespace: boolean;
  examPassingWPM: number; // default e.g. 30 for Hindi, 35 for English
  examPassingAccuracy: number; // default e.g. 90%
}
