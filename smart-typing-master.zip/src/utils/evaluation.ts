import { 
  DetailedError, 
  DiffToken, 
  EvaluationResult, 
  Language, 
  PracticeMode 
} from '../types';

/**
 * Normalizes text for comparison:
 * - NFC Unicode normalization (vital for Hindi Devanagari matras, conjuncts, nuktas)
 * - Optionally collapses multiple spaces and trims outer whitespace
 */
export function normalizeText(text: string, strictWhitespace: boolean = false): string {
  if (!text) return '';
  let normalized = text.normalize('NFC');
  
  if (!strictWhitespace) {
    // Replace multiple spaces/newlines with single space, trim start/end
    normalized = normalized.replace(/\r\n/g, '\n').replace(/[ \t]+/g, ' ').trim();
  }
  return normalized;
}

/**
 * Tokenizes text into words while keeping punctuation context.
 * Works seamlessly with both English and Hindi Unicode script.
 */
export function tokenizeWords(text: string): string[] {
  if (!text.trim()) return [];
  // Split on whitespace
  return text.trim().split(/\s+/).filter(Boolean);
}

/**
 * Levenshtein distance calculation between two strings.
 */
export function getLevenshteinDistance(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  const dp: number[][] = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));

  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;

  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (a[i - 1] === b[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1];
      } else {
        dp[i][j] = 1 + Math.min(
          dp[i - 1][j],     // deletion
          dp[i][j - 1],     // insertion
          dp[i - 1][j - 1]  // substitution
        );
      }
    }
  }
  return dp[m][n];
}

/**
 * Word Sequence Alignment using dynamic programming (Needleman-Wunsch / Levenshtein on words)
 * This aligns refWords and typedWords to identify:
 * - Exact matches (correct)
 * - Mismatches (spelling errors or punctuation errors)
 * - Missing words (in reference, skipped by typist)
 * - Extra words (typed by typist, not in reference)
 */
interface WordAlignment {
  refWord: string | null;
  typedWord: string | null;
}

function alignWordSequences(refWords: string[], typedWords: string[]): WordAlignment[] {
  const m = refWords.length;
  const n = typedWords.length;

  // DP table for cost minimization
  // MATCH: cost 0 if identical, or proportional to edit distance if similar
  // INSERTION / DELETION cost: 1.5
  const dp: number[][] = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));

  for (let i = 0; i <= m; i++) dp[i][0] = i * 1.5;
  for (let j = 0; j <= n; j++) dp[0][j] = j * 1.5;

  for (let i = 1; i <= m; i++) {
    const rw = refWords[i - 1];
    for (let j = 1; j <= n; j++) {
      const tw = typedWords[j - 1];
      
      let cost = 0;
      if (rw === tw) {
        cost = 0;
      } else {
        const dist = getLevenshteinDistance(rw, tw);
        const maxLen = Math.max(rw.length, tw.length);
        const ratio = dist / Math.max(maxLen, 1);
        // If words are moderately similar (ratio < 0.6), cost is between 0.3 and 1.2
        cost = ratio < 0.6 ? ratio * 1.5 : 2.5;
      }

      dp[i][j] = Math.min(
        dp[i - 1][j - 1] + cost, // substitution / match
        dp[i - 1][j] + 1.5,      // deletion (missing word)
        dp[i][j - 1] + 1.5       // insertion (extra word)
      );
    }
  }

  // Backtrack to find optimal alignment path
  const alignment: WordAlignment[] = [];
  let i = m;
  let j = n;

  while (i > 0 || j > 0) {
    if (i > 0 && j > 0) {
      const rw = refWords[i - 1];
      const tw = typedWords[j - 1];
      let cost = 0;
      if (rw === tw) {
        cost = 0;
      } else {
        const dist = getLevenshteinDistance(rw, tw);
        const maxLen = Math.max(rw.length, tw.length);
        const ratio = dist / Math.max(maxLen, 1);
        cost = ratio < 0.6 ? ratio * 1.5 : 2.5;
      }

      const matchScore = dp[i - 1][j - 1] + cost;
      const deleteScore = dp[i - 1][j] + 1.5;
      const insertScore = dp[i][j - 1] + 1.5;

      if (Math.abs(dp[i][j] - matchScore) < 1e-6) {
        alignment.push({ refWord: rw, typedWord: tw });
        i--;
        j--;
        continue;
      } else if (Math.abs(dp[i][j] - deleteScore) < 1e-6) {
        alignment.push({ refWord: rw, typedWord: null });
        i--;
        continue;
      } else {
        alignment.push({ refWord: null, typedWord: tw });
        j--;
        continue;
      }
    } else if (i > 0) {
      alignment.push({ refWord: refWords[i - 1], typedWord: null });
      i--;
    } else {
      alignment.push({ refWord: null, typedWord: typedWords[j - 1] });
      j--;
    }
  }

  return alignment.reverse();
}

/**
 * Character-level diff between two words for visual inspection.
 */
function getCharDiffs(expected: string, typed: string): { char: string; status: 'correct' | 'incorrect' | 'missing' | 'extra' }[] {
  const result: { char: string; status: 'correct' | 'incorrect' | 'missing' | 'extra' }[] = [];
  const maxLen = Math.max(expected.length, typed.length);

  for (let i = 0; i < maxLen; i++) {
    const expChar = expected[i];
    const typChar = typed[i];

    if (expChar && typChar) {
      if (expChar === typChar) {
        result.push({ char: typChar, status: 'correct' });
      } else {
        result.push({ char: typChar, status: 'incorrect' });
      }
    } else if (typChar && !expChar) {
      result.push({ char: typChar, status: 'extra' });
    } else if (expChar && !typChar) {
      result.push({ char: expChar, status: 'missing' });
    }
  }
  return result;
}

/**
 * Detect specific error type between expected word and typed word.
 */
function classifyWordError(expected: string | null, typed: string | null, language: Language): {
  type: DetailedError['type'];
  description: string;
} {
  if (expected && !typed) {
    return {
      type: 'missing_word',
      description: language === 'hindi' ? 'शब्द छूट गया (Missing Word)' : 'Missing word from passage'
    };
  }
  if (!expected && typed) {
    return {
      type: 'extra_word',
      description: language === 'hindi' ? 'अतिरिक्त शब्द टाइप किया (Extra Word)' : 'Extra word not in passage'
    };
  }
  if (expected && typed) {
    // Check if only case difference (English only)
    if (language === 'english' && expected.toLowerCase() === typed.toLowerCase()) {
      return {
        type: 'case_error',
        description: 'Letter capitalization mismatch'
      };
    }

    // Check if only punctuation difference
    const expNoPunct = expected.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?"'।'॥]/g, '');
    const typNoPunct = typed.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()?"'।'॥]/g, '');
    if (expNoPunct === typNoPunct && expNoPunct.length > 0) {
      return {
        type: 'punctuation',
        description: language === 'hindi' ? 'विराम चिह्न या मात्रा त्रुटि' : 'Punctuation mark error'
      };
    }

    // Single character typo vs general spelling
    const dist = getLevenshteinDistance(expected, typed);
    if (dist === 1) {
      return {
        type: 'wrong_char',
        description: language === 'hindi' ? 'एक वर्ण/मात्रा त्रुटि' : 'Single character typo'
      };
    }

    return {
      type: 'spelling',
      description: language === 'hindi' ? 'गलत शब्द / मात्रा त्रुटि' : 'Spelling mistake'
    };
  }

  return {
    type: 'spelling',
    description: 'Unknown error'
  };
}

/**
 * Evaluates student's typed text against reference passage.
 */
export function evaluateTyping(params: {
  referenceText: string;
  typedText: string;
  durationSeconds: number;
  language: Language;
  mode: PracticeMode;
  passageId?: string;
  passageTitle: string;
  studentName: string;
  strictWhitespace?: boolean;
}): EvaluationResult {
  const {
    referenceText,
    typedText,
    durationSeconds,
    language,
    mode,
    passageId,
    passageTitle,
    studentName,
    strictWhitespace = false
  } = params;

  // Ensure minimum elapsed time of 1 second for rate calculations
  const safeDuration = Math.max(durationSeconds, 1);
  const minutes = safeDuration / 60;

  // Format time mm:ss
  const mins = Math.floor(safeDuration / 60);
  const secs = Math.floor(safeDuration % 60);
  const timeFormatted = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;

  // Unicode Normalization (NFC)
  const normRef = normalizeText(referenceText, strictWhitespace);
  const normTyped = normalizeText(typedText, strictWhitespace);

  // Reference & typed word arrays
  const refWords = tokenizeWords(normRef);
  const typedWords = tokenizeWords(normTyped);

  const totalReferenceWords = refWords.length;
  const totalWordsTyped = typedWords.length;

  // Align word sequences
  const wordAlignments = alignWordSequences(refWords, typedWords);

  let correctWords = 0;
  let incorrectWords = 0;
  let missingWords = 0;
  let extraWords = 0;

  const errors: DetailedError[] = [];
  const diffTokens: DiffToken[] = [];

  let errorCounter = 1;

  for (const align of wordAlignments) {
    const { refWord, typedWord } = align;

    if (refWord !== null && typedWord !== null) {
      if (refWord === typedWord) {
        correctWords++;
        diffTokens.push({
          type: 'correct',
          expected: refWord,
          typed: typedWord
        });
      } else {
        incorrectWords++;
        const { type, description } = classifyWordError(refWord, typedWord, language);
        errors.push({
          index: errorCounter++,
          expected: refWord,
          typed: typedWord,
          type,
          description
        });
        diffTokens.push({
          type: 'incorrect',
          expected: refWord,
          typed: typedWord,
          charDiffs: getCharDiffs(refWord, typedWord)
        });
      }
    } else if (refWord !== null && typedWord === null) {
      missingWords++;
      errors.push({
        index: errorCounter++,
        expected: refWord,
        typed: '— (छूट गया)',
        type: 'missing_word',
        description: language === 'hindi' ? 'गद्यांश का शब्द छूट गया' : 'Omitted word from passage'
      });
      diffTokens.push({
        type: 'missing',
        expected: refWord
      });
    } else if (refWord === null && typedWord !== null) {
      extraWords++;
      errors.push({
        index: errorCounter++,
        expected: '—',
        typed: typedWord,
        type: 'extra_word',
        description: language === 'hindi' ? 'अतिरिक्त शब्द जोड़ा गया' : 'Unsolicited extra word'
      });
      diffTokens.push({
        type: 'extra',
        typed: typedWord
      });
    }
  }

  // Character level statistics
  // Direct character comparison through Levenshtein alignment
  let correctChars = 0;
  let incorrectChars = 0;
  let extraChars = 0;
  let missingChars = 0;

  const totalReferenceChars = normRef.length;
  const totalCharsTyped = normTyped.length;

  // Accurate char-level calculation:
  // Iterate through aligned words to sum characters
  for (const align of wordAlignments) {
    if (align.refWord && align.typedWord) {
      const minL = Math.min(align.refWord.length, align.typedWord.length);
      for (let c = 0; c < minL; c++) {
        if (align.refWord[c] === align.typedWord[c]) {
          correctChars++;
        } else {
          incorrectChars++;
        }
      }
      if (align.typedWord.length > align.refWord.length) {
        extraChars += (align.typedWord.length - align.refWord.length);
      } else if (align.refWord.length > align.typedWord.length) {
        missingChars += (align.refWord.length - align.typedWord.length);
      }
    } else if (align.refWord && !align.typedWord) {
      missingChars += align.refWord.length;
    } else if (!align.refWord && align.typedWord) {
      extraChars += align.typedWord.length;
    }
  }

  // Include space character calculations accurately
  const expectedSpaces = Math.max(0, totalReferenceWords - 1);
  const typedSpaces = Math.max(0, totalWordsTyped - 1);
  const correctSpaces = Math.min(expectedSpaces, typedSpaces);
  correctChars += correctSpaces;

  // Speed Formulas
  // Standard typing definition: 1 Word = 5 keystrokes / characters (international standard & SSC rule)
  // Gross WPM = (Total characters typed / 5) / Time (min)
  const grossWPM = Math.round((totalCharsTyped / 5) / minutes);

  // Net WPM = Gross WPM - (Total Errors / Time (min))
  // Where Total Errors = incorrectWords + missingWords + extraWords
  const totalErrors = incorrectWords + missingWords + extraWords;
  const errorPenalty = totalErrors / minutes;
  const netWPM = Math.max(0, Math.round(grossWPM - errorPenalty));

  // CPM = Characters Per Minute
  const cpm = Math.round(totalCharsTyped / minutes);

  // Accuracy calculation
  // Accuracy % = (Correct Words / Total Words Processed) * 100
  // Or character-based: (Correct Chars / (Total Chars Typed + Missing Chars)) * 100
  let accuracyPercentage = 0;
  if (totalWordsTyped > 0) {
    const accuracyWords = (correctWords / (correctWords + incorrectWords + extraWords)) * 100;
    accuracyPercentage = Math.max(0, Math.min(100, Math.round(accuracyWords * 10) / 10));
  }

  // Error Percentage
  const errorPercentage = Math.round((100 - accuracyPercentage) * 10) / 10;

  // Passage Completion Percentage
  const completionPercentage = totalReferenceWords > 0 
    ? Math.min(100, Math.round((correctWords / totalReferenceWords) * 100))
    : 0;

  // Performance Rating calculation
  let performanceGrade: EvaluationResult['performanceGrade'] = 'Beginner';
  let performanceDescription = '';

  if (accuracyPercentage >= 95 && netWPM >= 45) {
    performanceGrade = 'Excellent';
    performanceDescription = language === 'hindi' 
      ? 'अति उत्कृष्ट! आपकी गति और शुद्धता दोनों परीक्षा स्तर पर खरी उतरती हैं।' 
      : 'Outstanding! Your speed and accuracy are well above official recruitment standards.';
  } else if (accuracyPercentage >= 90 && netWPM >= 35) {
    performanceGrade = 'Very Good';
    performanceDescription = language === 'hindi' 
      ? 'बहुत बढ़िया! आप सरकारी टंकण परीक्षा उत्तीर्ण करने के बहुत निकट हैं।' 
      : 'Very good! You qualify for most government and secretarial typing exams.';
  } else if (accuracyPercentage >= 85 && netWPM >= 25) {
    performanceGrade = 'Good';
    performanceDescription = language === 'hindi' 
      ? 'अच्छा प्रदर्शन! नियमित अभ्यास से गति और शुद्धता और बेहतर होगी।' 
      : 'Good effort! Continued daily practice will quickly elevate your speed.';
  } else if (accuracyPercentage >= 75 && netWPM >= 15) {
    performanceGrade = 'Improving';
    performanceDescription = language === 'hindi' 
      ? 'सुधार हो रहा है! ध्यान दें कि गलतियों को कम करें, गति स्वतः बढ़ जाएगी।' 
      : 'Steady progress! Prioritize keystroke accuracy over raw speed.';
  } else {
    performanceGrade = 'Beginner';
    performanceDescription = language === 'hindi' 
      ? 'शुरुआती स्तर। घबराएं नहीं, उंगलियों की सही स्थिति के साथ अभ्यास जारी रखें।' 
      : 'Beginner level. Focus on finger positioning and touch typing fundamentals.';
  }

  const hindiSpeedLabel = language === 'hindi' 
    ? `${netWPM} शब्द/मिनट (${grossWPM} सकल)` 
    : undefined;

  return {
    id: `result-${Date.now()}`,
    studentName,
    date: new Date().toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }),
    timestamp: Date.now(),
    language,
    mode,
    passageId,
    passageTitle,
    durationSeconds: safeDuration,
    timeFormatted,
    totalReferenceWords,
    totalWordsTyped,
    correctWords,
    incorrectWords,
    missingWords,
    extraWords,
    totalReferenceChars,
    totalCharsTyped,
    correctChars,
    incorrectChars,
    missingChars,
    extraChars,
    grossWPM,
    netWPM,
    cpm,
    hindiSpeedLabel,
    accuracyPercentage,
    errorPercentage,
    completionPercentage,
    performanceGrade,
    performanceDescription,
    errors,
    diffTokens,
    originalTypedText: typedText,
    referenceText
  };
}

/**
 * Honest evaluation for Free Text Practice mode (no reference passage).
 * Calculates only what is truthfully measurable.
 */
export function evaluateFreeTyping(params: {
  typedText: string;
  durationSeconds: number;
  language: Language;
  studentName: string;
}): EvaluationResult {
  const { typedText, durationSeconds, language, studentName } = params;
  const safeDuration = Math.max(durationSeconds, 1);
  const minutes = safeDuration / 60;

  const mins = Math.floor(safeDuration / 60);
  const secs = Math.floor(safeDuration % 60);
  const timeFormatted = `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;

  const words = tokenizeWords(typedText);
  const totalWordsTyped = words.length;
  const totalCharsTyped = typedText.length;

  const grossWPM = Math.round((totalCharsTyped / 5) / minutes);
  const cpm = Math.round(totalCharsTyped / minutes);

  return {
    id: `free-${Date.now()}`,
    studentName,
    date: new Date().toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }),
    timestamp: Date.now(),
    language,
    mode: 'text_practice',
    passageTitle: language === 'hindi' ? 'मुक्त अभ्यास (Free Practice)' : 'Free Text Practice',
    durationSeconds: safeDuration,
    timeFormatted,
    totalReferenceWords: 0,
    totalWordsTyped,
    correctWords: totalWordsTyped,
    incorrectWords: 0,
    missingWords: 0,
    extraWords: 0,
    totalReferenceChars: 0,
    totalCharsTyped,
    correctChars: totalCharsTyped,
    incorrectChars: 0,
    missingChars: 0,
    extraChars: 0,
    grossWPM,
    netWPM: grossWPM,
    cpm,
    hindiSpeedLabel: language === 'hindi' ? `${grossWPM} शब्द/मिनट` : undefined,
    accuracyPercentage: 100, // Not applicable
    errorPercentage: 0,
    completionPercentage: 100,
    performanceGrade: grossWPM >= 40 ? 'Excellent' : grossWPM >= 25 ? 'Good' : 'Improving',
    performanceDescription: language === 'hindi'
      ? `मुक्त अभ्यास सत्र सफलतापूर्वक संपन्न हुआ। सकल गति: ${grossWPM} शब्द/मिनट।`
      : `Free practice session completed. Gross speed: ${grossWPM} WPM.`,
    errors: [],
    diffTokens: [],
    originalTypedText: typedText,
    referenceText: '',
    isFreeTyping: true
  };
}
