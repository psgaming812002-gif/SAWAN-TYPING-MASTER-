import { jsPDF } from 'jspdf';
import { EvaluationResult } from '../types';

export function exportResultToPDF(result: EvaluationResult): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  let y = 18;

  // Header Banner
  doc.setFillColor(30, 58, 138); // Blue 900
  doc.rect(0, 0, pageWidth, 28, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.text('SAWAN TYPING', pageWidth / 2, 12, { align: 'center' });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.text('Official Typing Performance Assessment & Evaluation Report', pageWidth / 2, 20, { align: 'center' });

  y = 38;

  // Student Info Box
  doc.setFillColor(241, 245, 249);
  doc.roundedRect(14, y, pageWidth - 28, 22, 3, 3, 'F');
  doc.setDrawColor(203, 213, 225);
  doc.roundedRect(14, y, pageWidth - 28, 22, 3, 3, 'D');

  doc.setTextColor(30, 41, 59);
  doc.setFontSize(11);
  doc.setFont('helvetica', 'bold');
  doc.text(`Candidate: ${result.studentName || 'Student'}`, 18, y + 8);
  doc.text(`Test Date: ${result.date}`, 18, y + 16);

  doc.text(`Language: ${result.language.toUpperCase()}`, 115, y + 8);
  doc.text(`Passage: ${result.passageTitle}`, 115, y + 16);

  y += 30;

  // Primary Metrics Grid
  doc.setFontSize(13);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text('Executive Summary', 14, y);
  y += 5;

  const cardWidth = (pageWidth - 28 - 9) / 4;
  const cards = [
    { label: 'Net Speed', val: `${result.netWPM} WPM`, sub: `Gross: ${result.grossWPM} WPM`, bg: [238, 242, 255], border: [99, 102, 241] },
    { label: 'Accuracy', val: `${result.accuracyPercentage}%`, sub: `Errors: ${result.incorrectWords + result.missingWords + result.extraWords}`, bg: [240, 253, 244], border: [34, 197, 94] },
    { label: 'Total Time', val: result.timeFormatted, sub: `${result.durationSeconds} seconds`, bg: [254, 243, 199], border: [245, 158, 11] },
    { label: 'Rating', val: result.performanceGrade, sub: `${result.cpm} CPM`, bg: [250, 245, 255], border: [168, 85, 247] },
  ];

  cards.forEach((card, idx) => {
    const cardX = 14 + idx * (cardWidth + 3);
    doc.setFillColor(card.bg[0], card.bg[1], card.bg[2]);
    doc.roundedRect(cardX, y, cardWidth, 24, 2, 2, 'F');
    doc.setDrawColor(card.border[0], card.border[1], card.border[2]);
    doc.roundedRect(cardX, y, cardWidth, 24, 2, 2, 'D');

    doc.setFontSize(9);
    doc.setTextColor(100, 116, 139);
    doc.setFont('helvetica', 'normal');
    doc.text(card.label, cardX + cardWidth / 2, y + 6, { align: 'center' });

    doc.setFontSize(14);
    doc.setTextColor(15, 23, 42);
    doc.setFont('helvetica', 'bold');
    doc.text(card.val, cardX + cardWidth / 2, y + 14, { align: 'center' });

    doc.setFontSize(8);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(71, 85, 105);
    doc.text(card.sub, cardX + cardWidth / 2, y + 20, { align: 'center' });
  });

  y += 32;

  // Detailed Analysis Tables (Word & Character)
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text('Detailed Metric Breakdown', 14, y);
  y += 5;

  const halfWidth = (pageWidth - 28 - 4) / 2;

  // Left Box: Word Analysis
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(14, y, halfWidth, 52, 2, 2, 'F');
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(14, y, halfWidth, 52, 2, 2, 'D');

  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 58, 138);
  doc.text('Word Analysis', 18, y + 7);

  const wordMetrics = [
    ['Total Words Typed:', `${result.totalWordsTyped}`],
    ['Reference Words:', `${result.totalReferenceWords}`],
    ['Correct Words:', `${result.correctWords}`],
    ['Incorrect Words:', `${result.incorrectWords}`],
    ['Missing Words:', `${result.missingWords}`],
    ['Extra Words:', `${result.extraWords}`],
  ];

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(51, 65, 85);
  wordMetrics.forEach(([label, val], idx) => {
    const rowY = y + 14 + idx * 6;
    doc.text(label, 18, rowY);
    doc.text(val, 14 + halfWidth - 8, rowY, { align: 'right' });
  });

  // Right Box: Character Analysis
  const rightX = 14 + halfWidth + 4;
  doc.setFillColor(248, 250, 252);
  doc.roundedRect(rightX, y, halfWidth, 52, 2, 2, 'F');
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(rightX, y, halfWidth, 52, 2, 2, 'D');

  doc.setFontSize(10);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 58, 138);
  doc.text('Character & Speed Analysis', rightX + 4, y + 7);

  const charMetrics = [
    ['Characters Typed:', `${result.totalCharsTyped}`],
    ['Reference Characters:', `${result.totalReferenceChars}`],
    ['Correct Characters:', `${result.correctChars}`],
    ['Incorrect Characters:', `${result.incorrectChars}`],
    ['Keystrokes Per Min (CPM):', `${result.cpm}`],
    ['Passage Completion:', `${result.completionPercentage}%`],
  ];

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(51, 65, 85);
  charMetrics.forEach(([label, val], idx) => {
    const rowY = y + 14 + idx * 6;
    doc.text(label, rightX + 4, rowY);
    doc.text(val, rightX + halfWidth - 8, rowY, { align: 'right' });
  });

  y += 60;

  // Error Report Table
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(15, 23, 42);
  doc.text(`Typographical Error Audit (${result.errors.length} detected)`, 14, y);
  y += 5;

  // Table header
  doc.setFillColor(226, 232, 240);
  doc.rect(14, y, pageWidth - 28, 7, 'F');
  doc.setFontSize(8.5);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 41, 59);
  doc.text('No.', 17, y + 5);
  doc.text('Expected Content', 28, y + 5);
  doc.text('Your Input', 80, y + 5);
  doc.text('Error Classification', 135, y + 5);
  y += 7;

  if (result.errors.length === 0) {
    doc.setFontSize(9);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(22, 101, 52);
    doc.text('Perfect score! Zero typographical errors detected throughout the passage.', 18, y + 8);
    y += 14;
  } else {
    // Show up to 10 errors on the scorecard
    const displayErrors = result.errors.slice(0, 10);
    displayErrors.forEach((err, idx) => {
      if (y > 265) return; // avoid page overflow
      const bg = idx % 2 === 0 ? 255 : 248;
      doc.setFillColor(bg, bg, bg);
      doc.rect(14, y, pageWidth - 28, 6.5, 'F');

      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(71, 85, 105);
      doc.text(`${err.index}`, 17, y + 4.5);

      doc.setTextColor(22, 101, 52);
      // Clean non-printable or Hindi script text for PDF helvetica compatibility
      const expClean = err.expected.length > 25 ? err.expected.substring(0, 25) + '...' : err.expected;
      doc.text(expClean, 28, y + 4.5);

      doc.setTextColor(185, 28, 28);
      const typClean = err.typed.length > 25 ? err.typed.substring(0, 25) + '...' : err.typed;
      doc.text(typClean, 80, y + 4.5);

      doc.setTextColor(71, 85, 105);
      doc.text(err.description, 135, y + 4.5);
      y += 6.5;
    });

    if (result.errors.length > 10) {
      doc.setFontSize(8);
      doc.setFont('helvetica', 'italic');
      doc.setTextColor(100, 116, 139);
      doc.text(`+ ${result.errors.length - 10} additional errors logged in digital report.`, 18, y + 5);
      y += 8;
    }
  }

  // Footer / Exam standard notes
  y = Math.max(y + 8, 272);
  doc.setDrawColor(203, 213, 225);
  doc.line(14, y, pageWidth - 14, y);
  y += 4;

  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(148, 163, 184);
  doc.text('SAWAN TYPING Assessment Engine • 1 Word = 5 Keystrokes (SSC/Court Standard) • Evaluated via Sequence Alignment', 14, y);
  doc.text(`Report ID: ${result.id}`, pageWidth - 14, y, { align: 'right' });

  // Save the PDF
  const filename = `Typing_Report_${result.studentName.replace(/[^a-zA-Z0-9]/g, '_')}_${Date.now()}.pdf`;
  doc.save(filename);
}
