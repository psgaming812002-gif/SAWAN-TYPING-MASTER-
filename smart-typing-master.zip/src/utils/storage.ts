import { AppSettings, EvaluationResult, Language, UserProfile } from '../types';

const STORAGE_KEYS = {
  USER: 'stm_user_profile',
  SETTINGS: 'stm_settings',
  HISTORY: 'stm_practice_history',
  LAST_RESULT: 'stm_last_result',
} as const;

export const DEFAULT_SETTINGS: AppSettings = {
  studentName: '',
  defaultLanguage: 'english',
  defaultMode: 'page_typing',
  fontSize: 'md',
  theme: 'light',
  soundEnabled: true,
  strictWhitespace: false,
  examPassingWPM: 35,
  examPassingAccuracy: 90,
};

// USER PROFILE
export function getUserProfile(): UserProfile | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.USER);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to get user profile', err);
    return null;
  }
}

export function saveUserProfile(user: UserProfile): void {
  try {
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  } catch (err) {
    console.error('Failed to save user profile', err);
  }
}

export function clearUserProfile(): void {
  try {
    localStorage.removeItem(STORAGE_KEYS.USER);
  } catch (err) {
    console.error('Failed to clear user profile', err);
  }
}

// APP SETTINGS
export function getAppSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (!raw) return DEFAULT_SETTINGS;
    return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch (err) {
    console.error('Failed to get app settings', err);
    return DEFAULT_SETTINGS;
  }
}

export function saveAppSettings(settings: AppSettings): void {
  try {
    localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
  } catch (err) {
    console.error('Failed to save settings', err);
  }
}

// PRACTICE HISTORY
export function getPracticeHistory(): EvaluationResult[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.HISTORY);
    if (!raw) return [];
    const list: EvaluationResult[] = JSON.parse(raw);
    return Array.isArray(list) ? list : [];
  } catch (err) {
    console.error('Failed to get history', err);
    return [];
  }
}

export function saveHistoryItem(result: EvaluationResult): void {
  try {
    const history = getPracticeHistory();
    // Prepend newest first
    const updated = [result, ...history];
    // Keep up to 200 sessions to preserve browser storage
    const trimmed = updated.slice(0, 200);
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(trimmed));
    localStorage.setItem(STORAGE_KEYS.LAST_RESULT, JSON.stringify(result));
  } catch (err) {
    console.error('Failed to save history item', err);
  }
}

export function deleteHistoryItem(id: string): void {
  try {
    const history = getPracticeHistory();
    const updated = history.filter(item => item.id !== id);
    localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(updated));
  } catch (err) {
    console.error('Failed to delete history item', err);
  }
}

export function clearAllHistory(): void {
  try {
    localStorage.removeItem(STORAGE_KEYS.HISTORY);
    localStorage.removeItem(STORAGE_KEYS.LAST_RESULT);
  } catch (err) {
    console.error('Failed to clear history', err);
  }
}

export function getLastResult(): EvaluationResult | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.LAST_RESULT);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to get last result', err);
    return null;
  }
}

// DASHBOARD STATS CALCULATION
export interface DashboardStats {
  selectedLanguage: Language;
  totalTests: number;
  bestSpeedWPM: number;
  averageAccuracy: number;
  totalPracticeTimeFormatted: string;
  totalWordsTyped: number;
  recentResults: EvaluationResult[];
}

export function getDashboardStats(currentLanguage: Language): DashboardStats {
  const history = getPracticeHistory();
  // Filter by language for language-specific metrics, or combined
  const langHistory = history.filter(h => h.language === currentLanguage);

  let bestSpeed = 0;
  let totalAccuracy = 0;
  let passageTestsCount = 0;
  let totalDurationSecs = 0;
  let totalWords = 0;

  for (const item of history) {
    totalDurationSecs += item.durationSeconds || 0;
    totalWords += item.totalWordsTyped || 0;
  }

  for (const item of langHistory) {
    if (item.netWPM > bestSpeed) {
      bestSpeed = item.netWPM;
    }
    if (!item.isFreeTyping && item.accuracyPercentage !== undefined) {
      totalAccuracy += item.accuracyPercentage;
      passageTestsCount++;
    }
  }

  const avgAccuracy = passageTestsCount > 0 
    ? Math.round((totalAccuracy / passageTestsCount) * 10) / 10 
    : 0;

  // Format total practice time
  const hours = Math.floor(totalDurationSecs / 3600);
  const minutes = Math.floor((totalDurationSecs % 3600) / 60);
  const seconds = totalDurationSecs % 60;

  let totalPracticeTimeFormatted = '';
  if (hours > 0) {
    totalPracticeTimeFormatted = `${hours}h ${minutes}m`;
  } else if (minutes > 0) {
    totalPracticeTimeFormatted = `${minutes}m ${seconds}s`;
  } else {
    totalPracticeTimeFormatted = `${seconds}s`;
  }

  return {
    selectedLanguage: currentLanguage,
    totalTests: history.length,
    bestSpeedWPM: bestSpeed,
    averageAccuracy: avgAccuracy,
    totalPracticeTimeFormatted,
    totalWordsTyped: totalWords,
    recentResults: history.slice(0, 5),
  };
}

// EXPORT / IMPORT DATA
export function exportDataAsJson(): string {
  const data = {
    app: 'SAWAN TYPING',
    exportedAt: new Date().toISOString(),
    user: getUserProfile(),
    settings: getAppSettings(),
    history: getPracticeHistory(),
  };
  return JSON.stringify(data, null, 2);
}

export function resetApplicationData(): void {
  try {
    localStorage.removeItem(STORAGE_KEYS.USER);
    localStorage.removeItem(STORAGE_KEYS.SETTINGS);
    localStorage.removeItem(STORAGE_KEYS.HISTORY);
    localStorage.removeItem(STORAGE_KEYS.LAST_RESULT);
  } catch (err) {
    console.error('Failed to reset app data', err);
  }
}
